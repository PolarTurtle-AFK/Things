#include <stdio.h>
#include <stdlib.h>
#include "reporte.h"
#include "proyecto.h"

/*
Nombre: REPORTES
Que hace: Muestra el menu de Reportes y llama al reporte que el usuario elija.
Que recibe: Ocbz -> Nodo orden cabeza,
            Vcbz -> Nodo vehiculo cabeza,
            Ccbz -> Nodo cliente cabeza,
            Mcbz -> Nodo mecanico cabeza,
            Rcbz -> Nodo repuesto cabeza.
Que retorna: No retorna nada (void). Se queda en el menu hasta que se elige 0.
*/
void REPORTES(Norden **Ocbz, Nvehiculo **Vcbz, Ncliente **Ccbz, Nmecanico **Mcbz, Nrepuesto **Rcbz)
{
    int op;
    do
    {
        puts("+-----------------------------------------+");
        puts("|                                         |");
        printf("|============ MEN%c DE REPORTES ===========|\n", 233);
        puts("|                                         |");
        puts("+-----------------------------------------+\n");
        puts("+-----------------------------------------+");
        puts("| 1. Ingresos por Dia                     |");
        puts("| 2. Repuestos Mas Usados                 |");
        puts("| 3. Mecanico con Mas Ordenes Completadas |");
        puts("| 4. Ordenes Pendientes por Vehiculo      |");
        puts("| 0. Volver                               |");
        puts("+-----------------------------------------+");
        printf("Seleccione una opci%cn: ", 162);

        leerint(&op);

        switch(op)
        {
        case 1:
            system("cls");
            INGRESOS(Ocbz, Vcbz, Ccbz, Mcbz, Rcbz);
            break;

        case 2:
            system("cls");
            REP_MAS_USADOS(Ocbz, Vcbz, Ccbz, Mcbz, Rcbz);
            break;

        case 3:
            system("cls");
            MEC_MAS_ORDENES(Ocbz, Vcbz, Ccbz, Mcbz, Rcbz);
            break;

        case 4:
            system("cls");
            ORD_PENDIENTES(Ocbz, Vcbz, Ccbz, Mcbz, Rcbz);
            break;

        case 0:
            system("cls");
            break;

        default:
            mensaje("\nERROR: Tienes que ingresar un numero de las opciones que se muestran!");
            break;
        }
    }
    while(op != 0);
}

/*
Nombre: INGRESOS

Que hace: Suma el total facturado (totalFinal) de las ordenes no anuladas,
          agrupado por fecha de ingreso, e imprime el total por dia y el
          total general.

Que recibe: Ocbz -> Nodo orden cabeza (los demas parametros no se usan)

Que retorna: No retorna nada (void), solo imprime el reporte en pantalla.
*/
void INGRESOS(Norden **Ocbz, Nvehiculo **Vcbz, Ncliente **Ccbz, Nmecanico **Mcbz, Nrepuesto **Rcbz)
{
    if(*Ocbz == NULL)
    {
        mensaje("No hay ordenes para reportar.");
        return;
    }

    Fecha *fechas = (Fecha *) calloc(1, sizeof(Fecha));
    float *totales = (float *) calloc(1, sizeof(float));
    int cantFechas = 0;
    float granTotal = 0;

    Norden *IND = *Ocbz;
    while(IND)
    {
        if(IND->ot.estado != 0)
        {
            int i, encontrado = -1;
            for(i = 0; i < cantFechas; i++)
                if((fechas+i)->dia == IND->ot.fechaIngreso.dia &&
                        (fechas+i)->mes == IND->ot.fechaIngreso.mes &&
                        (fechas+i)->anio == IND->ot.fechaIngreso.anio)
                {
                    encontrado = i;
                    break;
                }

            if(encontrado == -1)
            {
                fechas = (Fecha *) realloc(fechas, (cantFechas + 1) * sizeof(Fecha));
                totales = (float *) realloc(totales, (cantFechas + 1) * sizeof(float));

                *(fechas+cantFechas) = IND->ot.fechaIngreso;
                *(totales+cantFechas) = 0;
                encontrado = cantFechas;
                cantFechas++;
            }

            *(totales+encontrado) += IND->ot.totalFinal;
            granTotal += IND->ot.totalFinal;
        }

        IND = IND->prox;
    }

    if(cantFechas == 0)
    {
        mensaje("No hay ingresos para reportar.");
        free(fechas);
        free(totales);
        return;
    }

    puts("==============================================");
    puts("||                                          ||");
    puts("||===         Ingresos por Dia           ===||");
    puts("||                                          ||");
    puts("==============================================\n");
    printf("%-10s | %-s\n", "FECHA", "Total Facturado");
    puts("==============================================");

    int i;
    for(i = 0; i < cantFechas; i++)
        printf("%02d/%02d/%04d | RD$ %.2f\n", (fechas+i)->dia, (fechas+i)->mes, (fechas+i)->anio, *(totales+i));

    puts("==============================================");
    printf("Total general facturado: RD$ %.2f\n", granTotal);

    free(fechas);
    free(totales);

    mensaje("\n");
}

/*
Nombre: REP_MAS_USADOS

Que hace: Recorre todas las ordenes no anuladas y suma la cantidad utilizada
          de cada repuesto (identificado por su nombre). Usa dos arreglos
          dinamicos paralelos: uno para los nombres (punteros a char) y
          otro para las cantidades (int). Luego imprime una tabla con cada
          repuesto y su total usado, y al final indica cual es el repuesto
          mas usado.

Que recibe: Ocbz -> lista de ordenes (cabeza).
           (Los demas parametros no se usan)

Que retorna: No retorna nada (void), solo imprime el reporte en pantalla.
*/
void REP_MAS_USADOS(Norden **Ocbz, Nvehiculo **Vcbz, Ncliente **Ccbz, Nmecanico **Mcbz, Nrepuesto **Rcbz)
{
    if(*Ocbz == NULL)
    {
        mensaje("No hay ordenes para reportar.");
        return;
    }

    char **nombres = NULL;
    int *cantidades = NULL;
    int totalAcum = 0;

    Norden *IND = *Ocbz;
    while(IND)
    {
        if(IND->ot.estado != 0)
        {
            for(int i = 0; i < IND->ot.cantRepuestos; i++)
            {
                Repuesto r = *(IND->ot.listaRepuestos+i);
                int idx = -1;
                for(int j = 0; j < totalAcum; j++)
                {
                    if(strcasecmp(*(nombres + j), r.nombre) == 0)
                    {
                        idx = j;
                        break;
                    }
                }
                if(idx == -1)
                {
                    nombres = (char **) realloc(nombres, (totalAcum + 1) * sizeof(char *));
                    cantidades = (int *) realloc(cantidades, (totalAcum + 1) * sizeof(int));
                    *(nombres + totalAcum) = (char *) malloc((strlen(r.nombre) + 1) * sizeof(char));
                    strcpy(*(nombres + totalAcum), r.nombre);
                    *(cantidades + totalAcum) = 0;
                    idx = totalAcum;
                    totalAcum++;
                }
                *(cantidades + idx) += r.cantidad;
            }
        }
        IND = IND->prox;
    }

    if(totalAcum == 0)
    {
        mensaje("No hay repuestos usados en ordenes no anuladas.");
        free(nombres);
        free(cantidades);
        return;
    }

    int maxCant = -1, maxIdx = -1;
    for(int i = 0; i < totalAcum; i++)
    {
        if(*(cantidades + i) > maxCant)
        {
            maxCant = *(cantidades + i);
            maxIdx = i;
        }
    }

    puts("==============================================");
    puts("||                                          ||");
    puts("||========== Repuestos Mas Usados ==========||");
    puts("||                                          ||");
    puts("==============================================\n");
    printf("%-*s | %-s\n", 25, "REPUESTO", "Cantidad Usada");
    puts("==============================================");

    for(int i = 0; i < totalAcum; i++)
        printf("%-*s | %d\n", 25, *(nombres + i), *(cantidades + i));

    puts("==============================================");
    if(maxIdx != -1)
        printf("Repuesto mas usado: %s\n", *(nombres + maxIdx), *(cantidades + maxIdx));

    for(int i = 0; i < totalAcum; i++)
        free(*(nombres + i));
    free(nombres);
    free(cantidades);

    mensaje("\n");
}

/*
Nombre: MEC_MAS_ORDENES
S
Que hace: Cuenta, por cada mecanico, cuantas ordenes suyas estan en estado
          Entregado (5), imprime la tabla y muestra cual mecanico tiene mas.

Que recibe: Ocbz -> Nodo orden cabeza,
            Mcbz -> Nodo mecanico cabeza
            (los demas parametros no se usan aqui)

Que retorna: No retorna nada (void), solo imprime el reporte en pantalla.
*/
void MEC_MAS_ORDENES(Norden **Ocbz, Nvehiculo **Vcbz, Ncliente **Ccbz, Nmecanico **Mcbz, Nrepuesto **Rcbz)
{
    if(*Mcbz == NULL)
    {
        mensaje("No hay mecanicos para reportar.");
        return;
    }

    puts("==============================================");
    puts("||                                          ||");
    puts("||=  Mecanico con Mas Ordenes Completadas  =||");
    puts("||                                          ||");
    puts("==============================================\n");
    printf("%-*s | %-s\n", 20, "MECANICO", "Ordenes Entregadas");
    puts("==============================================");

    char *mejorNombre = (char *) calloc(1, sizeof(char));
    *(mejorNombre) = '\n';
    int mejorCant = -1;

    Nmecanico *MEC = *Mcbz;
    while(MEC)
    {
        int cont = 0;
        Norden *IND = *Ocbz;
        while(IND)
        {
            if(IND->ot.idMecanico == MEC->mec.id && IND->ot.estado == 5)
                cont++;

            IND = IND->prox;
        }

        printf("%-*s | %d\n", 20, MEC->mec.nombre, cont);

        if(cont > mejorCant)
        {
            mejorCant = cont;
            mejorNombre = (char *) realloc(mejorNombre, (strlen(MEC->mec.nombre)+1) * sizeof(char));
            strcpy(mejorNombre, MEC->mec.nombre);
        }

        MEC = MEC->prox;
    }

    puts("==============================================");
    printf("Mecanico con mayor desempe%co: %s\n", 164, mejorNombre);
    mensaje("\n");
}

/*
Nombre: ORD_PENDIENTES

Que hace: Recorre las ordenes que no estan Anuladas (0) ni Entregadas (5) y
          las imprime junto con la placa del vehiculo y su estado actual.

Que recibe: Ocbz -> Nodo orden cabeza,
            Vcbz -> Nodo vehiculo cabeza
           (los demas parametros no se usan aqui)

Que retorna: No retorna nada (void), solo imprime el reporte en pantalla.
*/
void ORD_PENDIENTES(Norden **Ocbz, Nvehiculo **Vcbz, Ncliente **Ccbz, Nmecanico **Mcbz, Nrepuesto **Rcbz)
{
    if(*Ocbz == NULL)
    {
        mensaje("No hay ordenes para reportar.");
        return;
    }

    int pendientes = 0;
    Norden *IND = *Ocbz;
    while(IND)
    {
        if(IND->ot.estado != 0 && IND->ot.estado != 5)
        {
            pendientes++;
            break;
        }

        IND = IND->prox;
    }

    if(!pendientes)
    {
        mensaje("No hay ordenes pendientes");
        return;
    }

    Nvehiculo *VEH;
    IND = *Ocbz;

    puts("==============================================");
    puts("||                                          ||");
    puts("||===  Ordenes pendientes por vehiculo   ===||");
    puts("||                                          ||");
    puts("==============================================\n");
    printf("%-*s | %-s\n", 7, "PLACA", "Ordenes Pendientes");
    puts("==============================================");

    while(IND)
    {
        if(IND->ot.estado != 0 && IND->ot.estado != 5)
        {
            VEH = devolver_ind_veh(Vcbz, IND->ot.idVehiculo);

            printf("%-*s | %-s\n", 7, VEH->veh.placa, estado(IND->ot.estado));

            IND = IND->prox;
        }

    }

    mensaje("\n");
}

