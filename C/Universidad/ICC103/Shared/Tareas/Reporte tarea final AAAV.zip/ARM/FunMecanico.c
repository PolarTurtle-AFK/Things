#include <stdio.h>
#include <stdlib.h>
#include "mecanico.h"
#include "proyecto.h"

/*
Nombre: leer_arch_mec

Que hace: Abre (o crea si no existe) mecanicos.dat y carga cada registro
          guardado en disco como un nodo nuevo de la lista de mecanicos.

Que recibe: Mcbz -> Nodo mecanico cabeza,
            Mcl -> Nodo mecanico cola.

Que retorna: No retorna nada (void), deja la lista de mecanicos cargada en memoria.
*/
void leer_arch_mec(Nmecanico **Mcbz, Nmecanico **Mcl)
{
    Mecanico m;

    FILE *Mach = fopen("mecanicos.dat", "rb");

    if(Mach == NULL)
    {
        Mach = fopen("mecanicos.dat", "ab");
        if(Mach == NULL)
        {
            puts("no se pudo crear el archivo de clientes :(");
            exit(1);
        }
    }
    else
        while(fread(&m, sizeof(Mecanico), 1, Mach))
            *Mcl = Insertar_Nodo_Mec(Mcbz, Mcl, m);

    fclose(Mach);
}

/*
Nombre: buscar_id_mec

Que hace: Recorre la lista de mecanicos comparando el id de cada nodo con
          el id buscado.

Que recibe: Mcbz -> Nodo mecanico cabeza,
            referencia -> id que se busca.

Que retorna: La posicion (indice desde 0) del mecanico si lo encuentra,
             o -1 si ningun mecanico tiene ese id.
*/
int buscar_id_mec(Nmecanico **Mcbz, int referencia)
{
    Nmecanico *IND = *Mcbz;
    int cont = 0;
    while(IND)
    {
        if(IND->mec.id == referencia)
            return cont;
        else
            cont++;

        IND = IND->prox;
    }

    return -1;
}

/*
Nombre: CRUD_mec

Que hace: Muestra el submenu de Mecanicos (crear, listar, modificar,
          borrar/desactivar) y llama a la funcion correspondiente segun
          la opcion elegida.

Que recibe: Mcbz -> Nodo mecanico cabeza,
            Mcl -> Nodo mecanico cola,
            Ocbz -> Nodo orden cabeza (para saber si un mecanico tiene
            ordenes al editar/borrar).

Que retorna: No retorna nada (void); se mantiene en el submenu hasta que
             el usuario elige volver (0).
*/
void CRUD_mec(Nmecanico **Mcbz, Nmecanico **Mcl, Norden **Ocbz)
{
    int op;
    do
    {
        puts("+----------------------------------+");
        puts("|                                  |");
        printf("|======== MEN%c DE MEC%cNICOS =======|\n", 233, 181);
        puts("|                                  |");
        puts("+----------------------------------+\n");
        puts("+----------------------------------+");
        printf("| 1. Crear mec%cnico                |\n", 160);
        printf("| 2. Listar mec%cnicos              |\n", 160);
        printf("| 3. Modificar mec%cnico            |\n", 160);
        printf("| 4. Borrar/Desactivar mec%cnico    |\n", 160);
        puts("| 0. Volver                        |");
        puts("+----------------------------------+");
        printf("Seleccione una opci%cn: ", 162);

        leerint(&op);

        switch(op)
        {
        case 1:
            system("cls");
            CREATE_MECANICO(Mcbz, Mcl);
            break;

        case 2:
            system("cls");
            READ_MECANICO(Mcbz, Mcl);
            break;

        case 3:
            system("cls");
            UPDATE_MECANICO(Mcbz, Mcl, Ocbz);
            break;

        case 4:
            system("cls");
            DISABLE_MECANICO(Mcbz, Mcl, Ocbz);
            break;

        case 0:
            system("cls");
            break;

        default:
            mensaje("\nERROR: Tienes que ingresar un numero de las opciones que se muestran!");
            break;
        }
    }
    while(op != 0);
}

/*
Nombre: CREATE_MECANICO

Que hace: Pide id, nombre y especialidad validando cada dato (id unico y
          en rango, nombre unico solo con letras/guion/espacio), arma un
          Mecanico activo, lo inserta en la lista y lo agrega al final de
          mecanicos.dat.

Que recibe: Mcbz -> Nodo mecanico cabeza,
            Mcl -> Nodo mecanico cola.

Que retorna: No retorna nada (void); deja el nuevo mecanico creado en
             memoria.
*/
void CREATE_MECANICO(Nmecanico **Mcbz, Nmecanico **Mcl)
{
    Mecanico m;

    m.activo = 1;

    do
    {
        puts("===================================");
        puts("||                               ||");
        printf("||===  Creador de Mec%cnicos   ===||\n", 160);
        puts("||                               ||");
        puts("===================================\n");
        printf("Ingrese id del mecanico (1-32767): ");
        leerint(&m.id);

        if(m.id < 1 || m.id > 32767)
            mensaje("\nERROR: Ingrese un numero valido! (entre 0 y 32767)");
        else if(buscar_id_mec(Mcbz, m.id) >= 0)
        {
            mensaje("\nERROR: Este id ya existe elija otro por favor!");
            m.id = -1;
        }
    }
    while(m.id < 1 || m.id > 32767);
    system("cls");

    do
    {
        puts("===================================");
        puts("||                               ||");
        printf("||===  Creador de Mec%cnicos   ===||\n", 160);
        puts("||                               ||");
        puts("===================================\n");
        printf("Ingrese id del mecanico (1-32767): %d\n", m.id);
        printf("Ingrese nombre del mecanico (solo letras, guion y espacio): ");
        fgets(m.nombre, 50, stdin);
        limpiar_salto(m.nombre);
        if(validar_nombre(m.nombre))
            *(m.nombre) = '\n';
        else if(buscar_nombre_mec(Mcbz, m.nombre) >= 0)
        {
            mensaje("\nERROR: Este nombre ya existe elija otro!");
            *(m.nombre) = '\n';
        }
    }
    while(*(m.nombre) == '\n');
    system("cls");

    do
    {
        puts("===================================");
        puts("||                               ||");
        printf("||===  Creador de Mec%cnicos   ===||\n", 160);
        puts("||                               ||");
        puts("===================================\n");
        printf("Ingrese id del mecanico (1-32767): %d\n", m.id);
        printf("Ingrese nombre del mecanico (solo letras, guion y espacio): %s\n", m.nombre);
        printf("Ingrese especialidad: ");
        fgets(m.especialidad, 30, stdin);
        limpiar_salto(m.especialidad);
    }
    while(*(m.especialidad) == '\n');

    if((*Mcl = Insertar_Nodo_Mec(Mcbz, Mcl, m)) == NULL)
    {
        mensaje("\nNo se pudo crear el mecanico");
    }
    else
    {
        FILE *Mach = fopen("mecanicos.dat", "ab");
        if(Mach == NULL)
        {
            mensaje("\nError: No se pudo abrir el archivo de mecanicoss");
            return;
        }

        fwrite(&m, sizeof(Mecanico), 1, Mach);
        fclose(Mach);

        mensaje("\nSe creo el mecanico!");
    }

}

/*
Nombre: READ_MECANICO

Que hace: Calcula el ancho de columna segun el dato mas largo de cada campo
          e imprime una tabla con todos los mecanicos registrados y su estado.

Que recibe: Mcbz -> Nodo mecanico cabeza,
            Mcl -> Nodo mecanico cola (no se usa).

Que retorna: No retorna nada (void), solo imprime la lista en pantalla.
*/
void READ_MECANICO(Nmecanico **Mcbz, Nmecanico **Mcl)
{
    if(*Mcbz == NULL)
    {
        mensaje("\nERROR: No hay mecanicos aun, por favor cree alguno!");
        return;
    }

    int TamID = 2;
    int TamNOM = 6;
    int TamESP = 12;
    int TamEST = 6;
    impresion_mec(Mcbz, &TamID, &TamNOM, &TamESP);

    Nmecanico *IND = *Mcbz;
    puts("==================================");;
    puts("||                              ||");
    printf("||====  Lista de Mec%cnicos  ====||\n",160);
    puts("||                              ||");
    puts("==================================\n");
    printf("%-*s | %-*s | %-*s | %-*s\n", TamID,  "ID",
           TamNOM, "NOMBRE",
           TamESP, "ESPECIALIDAD",
           TamEST, "ESTADO");

    int i, j;
    for(i = 0, j = TamID + TamNOM + TamESP + TamEST; i < 1.5*j; i++)
        printf("=");
    printf("\n");
    while(IND)
    {
        printf("%-*d | %-*s | %-*s | %-*s\n", TamID, IND->mec.id,
               TamNOM, IND->mec.nombre,
               TamESP, IND->mec.especialidad,
               TamEST, IND->mec.activo == 1 ? "ACTIVO" : "INACTIVO");

        IND = IND->prox;
    }

    printf("\n");
    system("pause");
    system("cls");
}

/*
Nombre: UPDATE_MECANICO

Que hace: Busca el mecanico por id, muestra un submenu para elegir que
          campo modificar (repite hasta que el usuario presiona X), pide
          confirmacion y, si se confirma, actualiza el nodo en memoria y
          el registro en mecanicos.dat. Si el id cambio, actualiza tambien
          las ordenes que lo referencian.

Que recibe: Mcbz -> Nodo mecanico cabeza,
            Mcl -> Nodo mecanico cola,
            Ocbz -> Nodo orden cabeza (para el cambio de id).

Que retorna: No retorna nada (void).
*/
void UPDATE_MECANICO(Nmecanico **Mcbz, Nmecanico **Mcl, Norden **Ocbz)
{
    if(*Mcbz == NULL)
    {
        mensaje("\nERROR: No hay mecanicos aun, por favor cree alguno!");
        return;
    }

    int buscar, pos;
    printf("Ingrese el id del Mecanico a buscar: ");
    leerint(&buscar);
    if((pos = buscar_id_mec(Mcbz, buscar)) < 0)
    {
        mensaje("El ID no existe y/o no es valido");
        return;
    }

    system("cls");

    Mecanico m;
    Nmecanico *IND = *Mcbz;
    for(int i = 0; i < pos; i++)
        IND = IND->prox;

    m = IND->mec;

    char eleccion;

    do
    {
        puts("==================================");;
        puts("||                              ||");
        printf("||====  Modificar Mec%cnico  ====||\n",160);
        puts("||                              ||");
        puts("==================================");
        printf("1. ID: %d\n", m.id);
        printf("2. Nombre: %s\n", m.nombre);
        printf("3. Especialidad: %s\n", m.especialidad);
        printf("4. Estado: %s\n", m.activo == 1 ? "Activo" : "Inactivo");
        printf("X. Salir\n\n");
        printf("Seleccione una opcion: ");
        eleccion = getchar();
        if(eleccion != '\n')
            clean_teclado();

        switch(eleccion)
        {
        case '1':
            system("cls");
            do
            {
                printf("Ingrese el nuevo id del mecanico: ");
                leerint(&m.id);

                if(m.id < 1 || m.id > 32767)
                {
                    mensaje("\nERROR: Ingrese un numero valido! (entre 1 y 32767)");
                    m.id = -1;
                }
                else if(buscar_id_mec(Mcbz, m.id) >= 0)
                {
                    mensaje("\nERROR: Este id ya existe elija otro por favor!");
                    m.id = -1;
                }
            }
            while(m.id < 1 || m.id > 32767);
            system("cls");
            break;

        case '2':
            system("cls");
            do
            {
                printf("Ingrese el nuevo nombre: ");
                fgets(m.nombre, 50, stdin);
                limpiar_salto(m.nombre);
                if(*(m.nombre) != '\n')
                    if(validar_nombre(m.nombre))
                        *(m.nombre) = '\n';
                    else if(buscar_nombre_mec(Mcbz, m.nombre) >= 0)
                    {
                        mensaje("\nERROR: Esta nombre ya existe elija otro!");
                        *(m.nombre) = '\n';
                    }
            }
            while(*(m.nombre) == '\n');
            system("cls");
            break;

        case '3':
            system("cls");
            do
            {
                printf("Ingrese la nueva especialidad: ");
                fgets(m.especialidad, 30, stdin);
                limpiar_salto(m.especialidad);
            }
            while(*(m.especialidad) == '\n');
            system("cls");
            break;

        case '4':
            system("cls");
            do
            {
                printf("Quieres cambiar de estado de %s a %s? (S/N): ", m.activo == 1 ? "Activo" : "Inactivo", m.activo == 1 ? "Inactivo" : "Activo");
                elige(&eleccion);

                if(eleccion == 'S')
                {
                    if(m.activo == 1)
                        m.activo = 0;
                    else
                        m.activo = 1;

                    mensaje("Se cambio de estado!");
                }
            }
            while(eleccion != 'S' && eleccion != 'N');
            system("cls");
            break;

        case 'x':
        case 'X':
            system("cls");
            break;

        default:
            mensaje("\nERROR: Tienes que ingresar una de las opciones que se muestran!");
            break;
        }
    }
    while(eleccion != 'x' && eleccion != 'X');

    do
    {
        puts("==================================");;
        puts("||                              ||");
        printf("||====  Modificar Mec%cnico  ====||\n",160);
        puts("||                              ||");
        puts("==================================");
        printf("ID: %d\n", m.id);
        printf("Nombre: %s\n", m.nombre);
        printf("Especialidad: %s\n", m.especialidad);
        printf("Estado: %s\n", m.activo == 1 ? "Activo" : "Inactivo");
        printf("Quieres guardar los cambios? (S/N): ");
        elige(&eleccion);
        if(eleccion == 'N')
        {
            mensaje("\nNo se guardaron los cambios!");
            return;
        }

    }
    while(eleccion != 'S' && eleccion != 'N');

    FILE *Mach = fopen("mecanicos.dat", "r+b");
    if(Mach == NULL)
    {
        mensaje("\nError: Para abrir el archivo de mecanicos!");
        return;
    }

    IND->mec = m;
    fseek(Mach, pos * sizeof(Mecanico), SEEK_SET);
    fwrite(&m, sizeof(Mecanico), 1, Mach);
    fclose(Mach);
    if(buscar != m.id)
        actualizar_id_mec_en_ordenes(Ocbz, buscar, m.id);
    mensaje("\nSe guardaron los cambios correctamente!");
}

/*
Nombre: DISABLE_MECANICO

Que hace: Busca el mecanico por id y, tras confirmar con el usuario, si el
          mecanico ya tiene alguna orden asignada solo lo marca como
          inactivo; si nunca tuvo ordenes lo elimina por completo de la
          lista y de mecanicos.dat.

Que recibe: Mcbz -> Nodo mecanico cabeza,
            Mcl -> Nodo mecanico cola,
            Ocbz -> Nodo orden cabeza (para saber si el mecanico tiene ordenes).

Que retorna: No retorna nada (void).
*/
void DISABLE_MECANICO(Nmecanico **Mcbz, Nmecanico **Mcl, Norden **Ocbz)
{
    if(*Mcbz == NULL)
    {
        mensaje("\nERROR: No hay mecanicos aun, por favor cree alguno!");
        return;
    }

    int buscar, pos;
    printf("Ingrese el id del Mecanico a buscar: ");
    leerint(&buscar);
    if((pos = buscar_id_mec(Mcbz, buscar)) < 0)
    {
        mensaje("El ID No existe y/o no es valido");
        return;
    }

    system("cls");

    Nmecanico *IND = *Mcbz;
    for(int i = 0; i < pos; i++)
        IND = IND->prox;

    if(IND->mec.activo == 0)
    {
        mensaje("\nERROR: El mecanico ya se encuentra desactivado si desea activarlo vaya a modificar!");
        return;
    }
    else
    {
        char eleccion;

        do
        {
            puts("===========================================");;
            puts("||                                       ||");
            printf("||====  Borrar/Desactivar Mec%cnicos  ====||\n",160);
            puts("||                                       ||");
            puts("===========================================");
            printf("ID: %d\n", IND->mec.id);
            printf("Nombre: %s\n", IND->mec.nombre);
            printf("Especialidad: %s\n\n", IND->mec.especialidad);
            printf("Quieres borrar/desactivar a este mecanico? (S/N): ");
            elige(&eleccion);
            if(eleccion == 'N')
            {
                mensaje("\nEl mecanico no fue borrado/desactivado!");
                return;
            }
        }
        while(eleccion != 'S' && eleccion != 'N');
    }

    FILE *Mach = fopen("mecanicos.dat", "r+b");
    if(Mach == NULL)
    {
        mensaje("\nError: No se pudo abrir el archivo de mecanicos!");
        return;
    }

    Mecanico m;
    if(buscar_Orden_idmec(Ocbz, buscar) >= 0)
    {
        //Inactivarlo
        IND->mec.activo = 0;
        m = IND->mec;
        fseek(Mach, pos * sizeof(Mecanico), SEEK_SET);
        fwrite(&m, sizeof(Mecanico), 1, Mach);
        fclose(Mach);
        mensaje("\nEl mecanico ya tiene una Orden activa asi que no se borro solo se desactivo!");
    }
    else
    {
        //Borrarlo completamente
        FILE *temp = fopen("temp.dat", "wb");
        if(temp == NULL)
        {
            mensaje("\nError: no se pudo abrir el archivo temporal de mecanicos!");
            return;
        }

        if(IND->ant)
            IND->ant->prox = IND->prox;
        else
            *Mcbz = IND->prox;

        if(IND->prox)
            IND->prox->ant = IND->ant;
        else
            *Mcl = IND->ant;

        free(IND);

        while(fread(&m, sizeof(Mecanico), 1, Mach))
            if(m.id != buscar)
                fwrite(&m, sizeof(Mecanico), 1, temp);

        fclose(Mach);
        fclose(temp);

        remove("mecanicos.dat");
        rename("temp.dat", "mecanicos.dat");
        mensaje("\nMecanico borrado correctamente!");
    }
}

/*
Nombre: Insertar_Nodo_Mec

Que hace: Reserva memoria para un nodo nuevo, copia el mecanico dentro y lo
          engancha al final de la lista doblemente enlazada (o como primer
          nodo si la lista estaba vacia).

Que recibe: Mcbz -> Nodo mecanico cabeza,
            Mcl -> Nodo mecanico cola,
            m -> struct Mecanico ya validado que se quiere agregar.

Que retorna: Puntero al nodo nuevo (que pasa a ser la nueva cola), o NULL
             si no se pudo reservar memoria.
*/
Nmecanico *Insertar_Nodo_Mec(Nmecanico **Mcbz, Nmecanico **Mcl, Mecanico m)
{
    Nmecanico *nm = (Nmecanico *) calloc(1, sizeof(Nmecanico));

    if(nm == NULL)
    {
        printf("no se pudo asignar la memoria :(");
        return NULL;
    }

    nm->mec = m;
    nm->prox = NULL;
    nm->ant = *Mcl;

    if(*Mcbz == NULL)
        *Mcbz = nm;
    else if(*Mcl)
        (*Mcl)->prox = nm;

    return nm;
}

/*
Nombre: free_mec

Que hace: Recorre toda la lista de mecanicos liberando cada nodo con free.

Que recibe: Mcbz -> Nodo mecanico cabeza (primer nodo de la lista).

Que retorna: No retorna nada (void).
*/
void free_mec(Nmecanico *Mcbz)
{
    Nmecanico *IND = Mcbz;
    while(Mcbz)
    {
        IND = Mcbz->prox;
        free(Mcbz);
        Mcbz = IND;
    }
}
