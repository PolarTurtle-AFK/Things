#ifndef reporte_H
#define reporte_H
#include "structs.h"

void REPORTES(Norden **Ocbz, Nvehiculo **Vcbz, Ncliente **Ccbz, Nmecanico **Mcbz, Nrepuesto **Rcbz);
void INGRESOS(Norden **Ocbz, Nvehiculo **Vcbz, Ncliente **Ccbz, Nmecanico **Mcbz, Nrepuesto **Rcbz);
void REP_MAS_USADOS(Norden **Ocbz, Nvehiculo **Vcbz, Ncliente **Ccbz, Nmecanico **Mcbz, Nrepuesto **Rcbz);
void MEC_MAS_ORDENES(Norden **Ocbz, Nvehiculo **Vcbz, Ncliente **Ccbz, Nmecanico **Mcbz, Nrepuesto **Rcbz);
void ORD_PENDIENTES(Norden **Ocbz, Nvehiculo **Vcbz, Ncliente **Ccbz, Nmecanico **Mcbz, Nrepuesto **Rcbz);

#endif

