#include <stdio.h>
#include <stdlib.h>
#include "cliente.h"
#include "proyecto.h"

/*
Nombre: leer_arch_cl

Que hace: Abre (o crea si no existe) clientes.dat y carga cada registro
          guardado en disco como un nodo nuevo de la lista de clientes.

Que recibe: Ccbz -> Nodo cliente cabeza,
            Ccl -> Nodo cliente cola.

Que retorna: No retorna nada (void), deja la lista de clientes cargada en memoria.
*/
void leer_arch_cl(Ncliente **Ccbz, Ncliente **Ccl)
{
    Cliente c;

    FILE *Cach = fopen("clientes.dat", "rb");

    if(Cach == NULL)
    {
        Cach = fopen("clientes.dat", "ab");
        if(Cach == NULL)
        {
            puts("no se pudo crear el archivo de clientes :(");
            exit(1);
        }
    }
    else
        while(fread(&c, sizeof(Cliente), 1, Cach))
            *Ccl = Insertar_Nodo_Cl( Ccbz, Ccl, c);

    fclose(Cach);
}

/*
Nombre: buscar_id_cl

Que hace: Recorre la lista de clientes comparando el id de cada nodo con
          el id buscado.

Que recibe: Ccbz -> Nodo cliente cabeza,
            referencia -> id que se busca.

Que retorna: La posicion (indice desde 0) del cliente si lo encuentra,
             o -1 si ningun cliente tiene ese id.
*/
int buscar_id_cl(Ncliente **Ccbz, int referencia)
{
    Ncliente *IND = *Ccbz;
    int cont = 0;
    while(IND)
    {
        if(IND->cl.id == referencia)
            return cont;
        else
            cont++;

        IND = IND->prox;
    }

    return -1;
}

/*
Nombre: CRUD_cl

Que hace: Muestra el submenu de Clientes (crear, listar, modificar,
          borrar/desactivar) y llama a la funcion correspondiente segun
          la opcion elegida.

Que recibe: Ccbz -> Nodo cliente cabeza,
            Ccl -> Nodo cliente cola,
            Ocbz -> Nodo orden cabeza (para saber si un cliente tiene
            ordenes al editar/borrar).

Que retorna: No retorna nada (void); se mantiene en el submenu hasta que
             el usuario elige volver (0).
*/
void CRUD_cl(Ncliente **Ccbz, Ncliente **Ccl, Norden **Ocbz)
{
    int op;
    do
    {
        puts("+-------------------------------+");
        puts("|                               |");
        printf("|======= MEN%c DE CLIENTES ======|\n", 233);
        puts("|                               |");
        puts("+-------------------------------+\n");
        puts("+-------------------------------+");
        puts("| 1. Crear cliente              |");
        puts("| 2. Listar clientes            |");
        puts("| 3. Modificar cliente          |");
        puts("| 4. Borrar/Desactivar cliente  |");
        puts("| 0. Volver                     |");
        puts("+-------------------------------+");
        printf("Seleccione una opci%cn: ", 162);

        leerint(&op);

        switch(op)
        {
        case 1:
            system("cls");
            CREATE_CLIENTE(Ccbz, Ccl);
            break;

        case 2:
            system("cls");
            READ_CLIENTE(Ccbz, Ccl);
            break;

        case 3:
            system("cls");
            UPDATE_CLIENTE(Ccbz, Ccl, Ocbz);
            break;

        case 4:
            system("cls");
            DISABLE_CLIENTE(Ccbz, Ccl, Ocbz);
            break;

        case 0:
            system("cls");
            break;

        default:
            mensaje("\nERROR: Tienes que ingresar un numero de las opciones que se muestran!");
            break;
        }
    }
    while(op != 0);
}

/*
Nombre: CREATE_CLIENTE

Que hace: Pide id, nombre y telefono validando cada dato (id unico y
          en rango, nombre unico solo con letras/guion/espacio), arma un
          Cliente activo, lo inserta en la lista y lo agrega al final de
          clientes.dat.

Que recibe: Ccbz -> Nodo cliente cabeza,
            Ccl -> Nodo cliente cola.

Que retorna: No retorna nada (void); deja el nuevo cliente creado en
             memoria.
*/
void CREATE_CLIENTE(Ncliente **Ccbz, Ncliente **Ccl)
{
    Cliente c;

    c.activo = 1;

    do
    {
        puts("==================================");
        puts("||                              ||");
        puts("||===  Creador de Clientes   ===||");
        puts("||                              ||");
        puts("==================================\n");
        printf("Ingrese id del cliente (1-32767): ");
        leerint(&c.id);

        if(c.id < 1 || c.id > 32767)
            mensaje("\nERROR: Ingrese un numero valido! (entre 0 y 32767)");
        else if(buscar_id_cl(Ccbz, c.id) >= 0)
        {
            mensaje("\nERROR: Este id ya existe elija otro por favor!");
            c.id = -1;
        }

    }
    while(c.id < 1 || c.id > 32767);
    system("cls");

    do
    {
        puts("==================================");
        puts("||                              ||");
        puts("||===  Creador de Clientes   ===||");
        puts("||                              ||");
        puts("==================================\n");
        printf("Ingrese id del cliente (1-32767): %d\n", c.id);
        printf("Ingrese nombre del cliente (solo letras, guion y espacio): ");
        fgets(c.nombre, 50, stdin);
        limpiar_salto(c.nombre);
        if(validar_nombre(c.nombre))
            *(c.nombre) = '\n';
        else if(buscar_nombre_cl(Ccbz, c.nombre) >= 0)
        {
            mensaje("\nERROR: Este nombre ya existe elija otro!");
            *(c.nombre) = '\n';
        }
    }
    while(*(c.nombre) == '\n');
    system("cls");

    do
    {
        puts("==================================");
        puts("||                              ||");
        puts("||===  Creador de Clientes   ===||");
        puts("||                              ||");
        puts("==================================\n");
        printf("Ingrese id del cliente (1-32767): %d\n", c.id);
        printf("Ingrese nombre del cliente (solo letras, guion y espacio): %s\n", c.nombre);
        printf("Ingrese telefono (ej: 809-555-1234): ");
        fgets(c.telefono, 15, stdin);
        limpiar_salto(c.telefono);
        if(validar_telefono(c.telefono))
            *(c.telefono) = '\n';
        else if(buscar_telefono_cl(Ccbz, c.telefono) >= 0)
        {
            mensaje("\nERROR: Este telefono ya existe elija otro!");
            *(c.telefono) = '\n';
        }
    }
    while(*(c.telefono) == '\n');

    if((*Ccl = Insertar_Nodo_Cl(Ccbz, Ccl, c)) == NULL)
    {
        mensaje("\nERROR: No se pudo crear el cliente!");
    }
    else
    {
        FILE *Cach = fopen("clientes.dat", "ab");
        if(Cach == NULL)
        {
            mensaje("\nError: No se pudo abrir el archivo de clientes!");
            return;
        }

        fwrite(&c, sizeof(Cliente), 1, Cach);
        fclose(Cach);

        mensaje("\nSe creo el cliente!");
    }

}

/*
Nombre: READ_CLIENTE

Que hace: Calcula el ancho de columna segun el dato mas largo de cada campo
          e imprime una tabla con todos los clientes registrados y su estado.

Que recibe: Ccbz -> Nodo cliente cabeza,
            Ccl -> Nodo cliente cola (no se usa).

Que retorna: No retorna nada (void), solo imprime la lista en pantalla.
*/
void READ_CLIENTE(Ncliente **Ccbz, Ncliente **Ccl)
{
    if(*Ccbz == NULL)
    {
        mensaje("\nERROR: No hay clientes aun, por favor cree alguno!");
        return;
    }

    int TamID = 2;
    int TamNOM = 6;
    int TamTEL = 12;
    int TamEST = 6;
    impresion_cl(Ccbz, &TamID, &TamNOM);

    Ncliente *IND = *Ccbz;
    puts("==================================");;
    puts("||                              ||");
    puts("||=====  Lista de Clientes  ====||");
    puts("||                              ||");
    puts("==================================\n");
    printf("%-*s | %-*s | %-*s | %-*s\n", TamID, "ID",
           TamNOM, "NOMBRE",
           TamTEL, "TELEFONO",
           TamEST, "ESTADO");

    int i, j;
    for(i = 0, j = TamID + TamNOM + TamTEL + TamEST; i < 1.5*j; i++)
        printf("=");
    printf("\n");

    while(IND)
    {
        printf("%-*d | %-*s | %-*s | %-*s\n", TamID, IND->cl.id,
               TamNOM, IND->cl.nombre,
               TamTEL, IND->cl.telefono,
               TamEST, IND->cl.activo == 1 ? "ACTIVO" : "INACTIVO");

        IND = IND->prox;
    }

    printf("\n");
    system("pause");
    system("cls");
}

/*
Nombre: UPDATE_CLIENTE

Que hace: Busca el cliente por id, muestra un submenu para elegir que
          campo modificar (repite hasta que el usuario presiona X), pide
          confirmacion y, si se confirma, actualiza el nodo en memoria y
          el registro en clientes.dat. Si el id cambio, actualiza tambien
          las ordenes que lo referencian.

Que recibe: Ccbz -> Nodo cliente cabeza,
            Ccl -> Nodo cliente cola,
            Ocbz -> Nodo orden cabeza (para el cambio de id).

Que retorna: No retorna nada (void).
*/
void UPDATE_CLIENTE(Ncliente **Ccbz, Ncliente **Ccl, Norden **Ocbz)
{
    if(*Ccbz == NULL)
    {
        mensaje("\nERROR: No hay clientes aun, por favor cree alguno!");
        return;
    }

    int buscar, pos;
    printf("Ingrese el id del cliente a buscar: ");
    leerint(&buscar);
    if((pos = buscar_id_cl(Ccbz, buscar)) < 0)
    {
        mensaje("El ID no existe y/o no es valido");
        return;
    }

    system("cls");

    Cliente c;
    Ncliente *IND = *Ccbz;
    for(int i = 0; i < pos; i++)
        IND = IND->prox;

    c = IND->cl;

    char eleccion;

    do
    {
        puts("==================================");;
        puts("||                              ||");
        puts("||=====  Modificar Cliente  ====||");
        puts("||                              ||");
        puts("==================================");
        printf("1. ID: %d\n", c.id);
        printf("2. Nombre: %s\n", c.nombre);
        printf("3. Telefono: %s\n", c.telefono);
        printf("4. Estado: %s\n", c.activo == 1 ? "Activo" : "Inactivo");
        printf("X. Salir\n\n");
        printf("Seleccione una opcion: ");
        eleccion = getchar();
        if(eleccion != '\n')
            clean_teclado();

        switch(eleccion)
        {
        case '1':
            system("cls");
            do
            {
                printf("Ingrese el nuevo id del cliente: ");
                leerint(&c.id);

                if(c.id < 1 || c.id > 32767)
                {
                    mensaje("\nERROR: Ingrese un numero valido! (entre 1 y 32767)");
                    c.id = -1;
                }
                else if(buscar_id_cl(Ccbz, c.id) >= 0)
                {
                    mensaje("\nERROR: Este id ya existe elija otro por favor!");
                    c.id = -1;
                }
            }
            while(c.id < 1 || c.id > 32767);
            system("cls");
            break;

        case '2':
            system("cls");
            do
            {
                printf("Ingrese el nuevo nombre: ");
                fgets(c.nombre, 50, stdin);
                limpiar_salto(c.nombre);
                if(*(c.nombre) != '\n')
                    if(validar_nombre(c.nombre))
                        *(c.nombre) = '\n';
                    else if(buscar_nombre_cl(Ccbz, c.nombre) >= 0)
                    {
                        mensaje("\nERROR: Esta nombre ya existe elija otro!");
                        *(c.nombre) = '\n';
                    }
            }
            while(*(c.nombre) == '\n');
            system("cls");
            break;

        case '3':
            system("cls");
            do
            {
                printf("Ingrese el nuevo telefono: ");
                fgets(c.telefono, 15, stdin);
                limpiar_salto(c.telefono);
                if(*(c.telefono) != '\n')
                    if(validar_telefono(c.telefono))
                        *(c.telefono) = '\n';
                    else if(buscar_telefono_cl(Ccbz, c.telefono) >= 0)
                    {
                        mensaje("\nERROR: Esta telefono ya existe elija otro!");
                        *(c.telefono) = '\n';
                    }
            }
            while(*(c.telefono) == '\n');
            system("cls");
            break;

        case '4':
            system("cls");
            do
            {
                printf("Quieres cambiar de estado de %s a %s? (S/N): ", c.activo == 1 ? "Activo" : "Inactivo", c.activo == 1 ? "Inactivo" : "Activo");
                elige(&eleccion);

                if(eleccion == 'S')
                {
                    if(c.activo == 1)
                        c.activo = 0;
                    else
                        c.activo = 1;

                    mensaje("Se cambio de estado!");
                }
            }
            while(eleccion != 'S' && eleccion != 'N');
            system("cls");
            break;

        case 'x':
        case 'X':
            system("cls");
            break;

        default:
            mensaje("\nERROR: Tienes que ingresar una de las opciones que se muestran!");
            break;
        }
    }
    while(eleccion != 'x' && eleccion != 'X');

    do
    {
        puts("==================================");;
        puts("||                              ||");
        puts("||=====  Modificar Cliente  ====||");
        puts("||                              ||");
        puts("==================================");
        printf("ID: %d\n", c.id);
        printf("Nombre: %s\n", c.nombre);
        printf("Telefono: %s\n", c.telefono);
        printf("Estado: %s\n", c.activo == 1 ? "Activo" : "Inactivo");
        printf("Quiere guardar los cambios? (S/N): ");
        elige(&eleccion);
        if(eleccion == 'N')
        {
            mensaje("\nNo se guardaron los cambios!");
            return;
        }

    }
    while(eleccion != 'S' && eleccion != 'N');

    FILE *Cach = fopen("clientes.dat", "r+b");
    if(Cach == NULL)
    {
        mensaje("\nError: Para abrir el archivo de clientes!");;
        return;
    }

    IND->cl = c;
    fseek(Cach, pos * sizeof(Cliente), SEEK_SET);
    fwrite(&c, sizeof(Cliente), 1, Cach);
    fclose(Cach);
    if(buscar != c.id)
        actualizar_id_cl_en_ordenes(Ocbz, buscar, c.id);
    mensaje("\nSe guardaron los cambios correctamente!");
}

/*
Nombre: DISABLE_CLIENTE

Que hace: Busca el cliente por id y, tras confirmar con el usuario, si el
          cliente ya tiene alguna orden asignada solo lo marca como
          inactivo; si nunca tuvo ordenes lo elimina por completo de la
          lista y de clientes.dat.

Que recibe: Ccbz -> Nodo cliente cabeza,
            Ccl -> Nodo cliente cola,
            Ocbz -> Nodo orden cabeza (para saber si el cliente tiene ordenes).

Que retorna: No retorna nada (void).
*/
void DISABLE_CLIENTE(Ncliente **Ccbz, Ncliente **Ccl, Norden **Ocbz)
{
    if(*Ccbz == NULL)
    {
        mensaje("\nERROR: No hay clientes aun, por favor cree alguno!");
        return;
    }

    int buscar, pos;
    printf("Ingrese el id del cliente a buscar: ");
    leerint(&buscar);
    if((pos = buscar_id_cl(Ccbz, buscar)) < 0)
    {
        mensaje("El ID No existe y/o no es valido");
        return;
    }
    system("cls");

    Ncliente *IND = *Ccbz;
    for(int i = 0; i < pos; i++)
        IND = IND->prox;

    if(IND->cl.activo == 0)
    {
        mensaje("\nERROR: El cliente ya se encuentra desactivado si desea activarlo vaya a modificar!");
        return;
    }
    else
    {
        char eleccion;

        do
        {
            puts("=================================");
            puts("||                             ||");
            puts("|| Borrar/Desactivar  Clientes ||");
            puts("||                             ||");
            puts("=================================");
            printf("ID: %d\n", IND->cl.id);
            printf("Nombre: %s\n", IND->cl.nombre);
            printf("Telefono: %s\n\n", IND->cl.telefono);
            printf("Quieres borrar/desactivar a este cliente? (S/N): ");
            elige(&eleccion);
            if(eleccion == 'N')
            {
                mensaje("\nEl cliente no fue borrado/desactivado!");
                return;
            }
        }
        while(eleccion != 'S' && eleccion != 'N');
    }

    FILE *Cach = fopen("clientes.dat", "r+b");
    if(Cach == NULL)
    {
        mensaje("\nError: No se pudo abrir el archivo de clientes!");
        return;
    }

    Cliente c;
    if(buscar_Orden_idcl(Ocbz, buscar) >= 0)
    {
        //Inactivarlo
        IND->cl.activo = 0;
        c = IND->cl;
        fseek(Cach, pos * sizeof(Cliente), SEEK_SET);
        fwrite(&c, sizeof(Cliente), 1, Cach);
        fclose(Cach);
        mensaje("\nEl cliente ya tiene una Orden activa asi que no se borro solo se desactivo!");
    }
    else
    {
        //Borrarlo completamente
        FILE *temp = fopen("temp.dat", "wb");
        if(temp == NULL)
        {
            mensaje("\nError: no se pudo abrir el archivo temporal de clientes!");
            return;
        }

        if(IND->ant)
            IND->ant->prox = IND->prox;
        else
            *Ccbz = IND->prox;

        if(IND->prox)
            IND->prox->ant = IND->ant;
        else
            *Ccl = IND->ant;

        free(IND);

        while(fread(&c, sizeof(Cliente), 1, Cach))
            if(c.id != buscar)
                fwrite(&c, sizeof(Cliente), 1, temp);

        fclose(Cach);
        fclose(temp);

        remove("clientes.dat");
        rename("temp.dat", "clientes.dat");
        mensaje("\nCliente borrado correctamente!");
    }

}

/*
Nombre: Insertar_Nodo_Cl

Que hace: Reserva memoria para un nodo nuevo, copia el cliente dentro y lo
          engancha al final de la lista doblemente enlazada (o como primer
          nodo si la lista estaba vacia).

Que recibe: Ccbz -> Nodo cliente cabeza,
            Ccl -> Nodo cliente cola,
            c -> struct Cliente ya validado que se quiere agregar.

Que retorna: Puntero al nodo nuevo (que pasa a ser la nueva cola), o NULL
             si no se pudo reservar memoria.
*/
Ncliente *Insertar_Nodo_Cl(Ncliente **Ccbz, Ncliente **Ccl, Cliente c)
{
    Ncliente *nc = (Ncliente *) calloc(1, sizeof(Ncliente));

    if(nc == NULL)
    {
        printf("no se pudo asignar la memoria :(");
        return NULL;
    }

    nc->cl = c;
    nc->prox = NULL;
    nc->ant = *Ccl;

    if(*Ccbz == NULL)
        *Ccbz = nc;
    else if(*Ccl)
        (*Ccl)->prox = nc;

    return nc;
}

/*
Nombre: free_cl

Que hace: Recorre toda la lista de cleintes liberando cada nodo con free.

Que recibe: Ccbz -> Nodo cleinte cabeza (primer nodo de la lista).

Que retorna: No retorna nada (void).
*/
void free_cl(Ncliente *Ccbz)
{
    Ncliente *IND = Ccbz;
    while(Ccbz)
    {
        IND = Ccbz->prox;
        free(Ccbz);
        Ccbz = IND;
    }
}
