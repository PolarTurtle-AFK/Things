// Adrian Alexander Artiles Vargas
// 10170038
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "vehiculo.h"
#include "cliente.h"
#include "mecanico.h"
#include "OrdenTrabajo.h"
#include "proyecto.h"
#include "repuesto.h"
#include "reporte.h"

void menu_general(Nvehiculo **Vcbz, Nvehiculo **Vcl, Ncliente **Ccbz, Ncliente **Ccl, Nmecanico **Mcbz, Nmecanico **Mcl, Nrepuesto **Rcbz, Nrepuesto **Rcl, Norden **Ocbz, Norden** Ocl);

int main()
{
    Nvehiculo *Vcbz = NULL, *Vcl = NULL;
    leer_arch_veh(&Vcbz, &Vcl);

    Ncliente *Ccbz = NULL, *Ccl = NULL;
    leer_arch_cl(&Ccbz, &Ccl);

    Nmecanico *Mcbz = NULL, *Mcl = NULL;
    leer_arch_mec(&Mcbz, &Mcl);

    Nrepuesto *Rcbz = NULL, *Rcl = NULL;
    leer_arch_rep(&Rcbz, &Rcl);

    Norden *Ocbz = NULL, *Ocl = NULL;
    leer_arch_ot(&Ocbz, &Ocl);

    menu_general(&Vcbz, &Vcl, &Ccbz, &Ccl, &Mcbz, &Mcl, &Rcbz, &Rcl, &Ocbz, &Ocl);

    free_veh(Vcbz);
    free_cl(Ccbz);
    free_mec(Mcbz);
    free_ot(Ocbz);
    free_rep(Rcbz);

    printf("MUCHAS GRACIAS, HASTA LUEGO!\n");

    return 0;
}

void menu_general(Nvehiculo **Vcbz, Nvehiculo **Vcl, Ncliente **Ccbz, Ncliente **Ccl, Nmecanico **Mcbz, Nmecanico **Mcl, Nrepuesto **Rcbz, Nrepuesto **Rcl, Norden **Ocbz, Norden** Ocl)
{
    int op;
    do
    {
        puts("+---------------------------------------+");
        puts("|                                       |");
        puts("|==== Adrian Auto Repair Management ====|");
        puts("|                                       |");
        puts("+---------------------------------------+\n");
        puts("+---------------------------------------+");
        printf("| 1. Veh%cculos                          |\n", 161);
        puts("| 2. Clientes                           |");
        puts("| 3. Mecanicos                          |");
        puts("| 4. Respuestos                         |");
        puts("| 5. Ordenes de Trabajo                 |");
        puts("| 6. Reportes                           |");
        puts("| 0. Salir                              |");
        puts("+---------------------------------------+");
        printf("Seleccione una opci%cn: ", 162);

        leerint(&op);

        switch(op)
        {
        case 1:
            system("cls");
            CRUD_veh(Vcbz, Vcl, Ocbz);
            break;

        case 2:
            system("cls");
            CRUD_cl(Ccbz, Ccl, Ocbz);
            break;

        case 3:
            system("cls");
            CRUD_mec(Mcbz, Mcl, Ocbz);
            break;

        case 4:
            system("cls");
            CRUD_rep(Rcbz, Rcl, Ocbz);
            break;

        case 5:
            system("cls");
            ORDEN(Ocbz, Ocl, Vcbz, Ccbz, Mcbz, Rcbz);
            break;

        case 6:
            system("cls");
            REPORTES(Ocbz, Vcbz, Ccbz, Mcbz, Rcbz);
            break;

        case 0:
            system("cls");
            break;

        default:
            mensaje("\nERROR: Tienes que ingresar un numero de las opciones que se muestran!");
            break;
        }
    }
    while(op != 0);
}


