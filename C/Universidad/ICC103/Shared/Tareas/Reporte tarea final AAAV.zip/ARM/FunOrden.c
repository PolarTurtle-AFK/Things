#include <stdio.h>
#include <stdlib.h>
#include "OrdenTrabajo.h"
#include "proyecto.h"

/*
Nombre: leer_arch_ot

Que hace: Abre (o crea si no existe) OrdenesDeTrabajo.dat y carga cada registro
          guardado en disco como un nodo nuevo de la lista de ordenes.

Que recibe: Ocbz -> puntero al puntero cabeza de la lista de ordenes,
            Ocl  -> puntero al puntero cola de la lista de ordenes.

Que retorna: No retorna nada (void); deja la lista de ordenes cargada en memoria.
*/
void leer_arch_ot(Norden **Ocbz, Norden **Ocl)
{
    OrdenTrabajo o;

    FILE *Oach = fopen("OrdenesDeTrabajo.dat", "rb");

    if(Oach == NULL)
    {
        Oach = fopen("OrdenesDeTrabajo.dat", "ab");
        if(Oach == NULL)
        {
            puts("no se pudo crear el archivo de ordenes:(");
            exit(1);
        }
    }
    else
        while(fread(&o, sizeof(OrdenTrabajo), 1, Oach))
            *Ocl = Insertar_Nodo_Ord(Ocbz, Ocl, o);

    fclose(Oach);
}

/*
Nombre: buscar_NumOrden

Que hace: Recorre la lista de ordenes comparando el numero de orden de cada
          nodo con el numero buscado.

Que recibe: Ocbz      -> puntero al puntero cabeza de la lista de ordenes,
            referencia -> numero de orden que se busca.

Que retorna: La posicion (indice desde 0) de la orden si la encuentra,
             o -1 si ninguna orden tiene ese numero.
*/
int buscar_NumOrden(Norden **Ocbz, int referencia)
{
    Norden *IND = *Ocbz;
    int cont = 0;
    while(IND)
    {
        if(IND->ot.numeroOrden == referencia)
            return cont;
        else
            cont++;

        IND = IND->prox;
    }

    return -1;
}

/*
Nombre: buscar_Orden_idveh

Que hace: Recorre la lista de ordenes comparando el ID de vehiculo de cada
          nodo con el ID buscado.

Que recibe: Ocbz      -> puntero al puntero cabeza de la lista de ordenes,
            referencia -> ID de vehiculo que se busca.

Que retorna: La posicion (indice desde 0) de la primera orden que tenga ese
             ID de vehiculo, o -1 si ninguna orden lo tiene.
*/
int buscar_Orden_idveh(Norden **Ocbz, int referencia)
{
    Norden *IND = *Ocbz;
    int cont = 0;
    while(IND)
    {
        if(IND->ot.idVehiculo == referencia)
            return cont;
        else
            cont++;

        IND = IND->prox;
    }

    return -1;
}

/*
Nombre: buscar_Orden_idcl

Que hace: Recorre la lista de ordenes comparando el ID de cliente de cada
          nodo con el ID buscado.

Que recibe: Ocbz      -> puntero al puntero cabeza de la lista de ordenes,
            referencia -> ID de cliente que se busca.

Que retorna: La posicion (indice desde 0) de la primera orden que tenga ese
             ID de cliente, o -1 si ninguna orden lo tiene.
*/
int buscar_Orden_idcl(Norden **Ocbz, int referencia)
{
    Norden *IND = *Ocbz;
    int cont = 0;
    while(IND)
    {
        if(IND->ot.idCliente == referencia)
            return cont;
        else
            cont++;

        IND = IND->prox;
    }

    return -1;
}

/*
Nombre: buscar_Orden_idmec

Que hace: Recorre la lista de ordenes comparando el ID de mecanico de cada
          nodo con el ID buscado.

Que recibe: Ocbz      -> puntero al puntero cabeza de la lista de ordenes,
            referencia -> ID de mecanico que se busca.

Que retorna: La posicion (indice desde 0) de la primera orden que tenga ese
             ID de mecanico, o -1 si ninguna orden lo tiene.
*/
int buscar_Orden_idmec(Norden **Ocbz, int referencia)
{
    Norden *IND = *Ocbz;
    int cont = 0;
    while(IND)
    {
        if(IND->ot.idMecanico == referencia)
            return cont;
        else
            cont++;

        IND = IND->prox;
    }

    return -1;
}

/*
Nombre: buscar_Orden_idrep

Que hace: Recorre la lista de ordenes y, dentro de cada orden, busca un
          repuesto por su ID en el arreglo de repuestos utilizados. Devuelve
          la posicion de la orden y, mediante un parametro de salida, la
          posicion dentro del arreglo de repuestos.

Que recibe: Ocbz      -> puntero al puntero cabeza de la lista de ordenes,
            referencia -> ID de repuesto que se busca,
            lugar     -> puntero a entero donde se almacenara la posicion
                         del repuesto dentro del arreglo de la orden.

Que retorna: La posicion (indice desde 0) de la orden que contiene el repuesto,
             o -1 si ningun repuesto con ese ID aparece en ninguna orden.
             Ademas, modifica *lugar con la posicion en el arreglo de repuestos.
*/
int buscar_Orden_idrep(Norden **Ocbz, int referencia, int *lugar)
{
    Norden *IND = *Ocbz;
    int cont = 0, i;
    while(IND)
    {
        for(i = 0; i < IND->ot.cantRepuestos; i++)
            if((IND->ot.listaRepuestos+i)->idRepuesto == referencia)
            {
                *lugar = i;
                return cont;
            }

        cont++;

        IND = IND->prox;
    }

    return -1;
}

/*
Nombre: ORDEN

Que hace: Muestra el submenu de Órdenes de Trabajo (crear, listar, ver detalle,
          cambiar estado, anular) y llama a la funcion correspondiente segun
          la opcion elegida.

Que recibe: Ocbz -> puntero al puntero cabeza de la lista de ordenes,
            Ocl  -> puntero al puntero cola de la lista de ordenes,
            Vcbz -> puntero al puntero cabeza de la lista de vehiculos,
            Ccbz -> puntero al puntero cabeza de la lista de clientes,
            Mcbz -> puntero al puntero cabeza de la lista de mecanicos,
            Rcbz -> puntero al puntero cabeza de la lista de repuestos.

Que retorna: No retorna nada (void); se mantiene en el submenu hasta que
             el usuario elige volver (0).
*/
void ORDEN(Norden **Ocbz, Norden **Ocl, Nvehiculo **Vcbz, Ncliente **Ccbz, Nmecanico **Mcbz, Nrepuesto **Rcbz)
{
    int op;
    do
    {
        puts("+----------------------------------+");
        puts("|                                  |");
        printf("|========= MEN%c DE ORDENES ========|\n", 233);
        puts("|                                  |");
        puts("+----------------------------------+\n");
        puts("+----------------------------------+");
        puts("| 1. Crear orden                   |");
        puts("| 2. Listar ordenes                |");
        puts("| 3. Ver detalle de orden          |");
        puts("| 4. Cambiar estado de orden       |");
        puts("| 5. Anular orden                  |");
        puts("| 0. Volver                        |");
        puts("+----------------------------------+");
        printf("Seleccione una opci%cn: ", 162);

        leerint(&op);

        switch(op)
        {
        case 1:
            system("cls");
            CREAR_ORDEN(Ocbz, Ocl, Vcbz, Ccbz, Mcbz, Rcbz);
            break;

        case 2:
            system("cls");
            LISTAR_ORDEN(Ocbz, Ocl, Vcbz, Ccbz, Mcbz, Rcbz);
            break;

        case 3:
            system("cls");
            DETALLAR_ORDEN(Ocbz, Ocl, Vcbz, Ccbz, Mcbz, Rcbz);
            break;

        case 4:
            system("cls");
            CAMBIAR_ESTADO_ORDEN(Ocbz, Ocl);
            break;

        case 5:
            system("cls");
            ANULAR_ORDEN(Ocbz, Ocl);
            break;

        case 0:
            system("cls");
            break;

        default:
            mensaje("\nERROR: Tienes que ingresar un numero de las opciones que se muestran!");
            break;
        }
    }
    while(op != 0);
}

/*
Nombre: CREAR_ORDEN

Que hace: Solicita al usuario todos los datos necesarios para crear una nueva
          orden de trabajo: numero de orden, ID de vehiculo, ID de cliente,
          ID de mecanico, fecha de ingreso, seleccion de repuestos y costo de
          mano de obra. Valida que los IDs existan y que el vehiculo no tenga
          otra orden activa. Calcula subtotal, ITBIS y total final. Inserta
          la orden en la lista y la guarda en el archivo.

Que recibe: Ocbz -> puntero al puntero cabeza de la lista de ordenes,
            Ocl  -> puntero al puntero cola de la lista de ordenes,
            Vcbz -> puntero al puntero cabeza de la lista de vehiculos,
            Ccbz -> puntero al puntero cabeza de la lista de clientes,
            Mcbz -> puntero al puntero cabeza de la lista de mecanicos,
            Rcbz -> puntero al puntero cabeza de la lista de repuestos.

Que retorna: No retorna nada (void); deja la nueva orden creada en memoria
             y persistida en disco.
*/
void CREAR_ORDEN(Norden **Ocbz, Norden **Ocl, Nvehiculo **Vcbz, Ncliente **Ccbz, Nmecanico **Mcbz, Nrepuesto **Rcbz)
{
    if(verificar(Vcbz, Ccbz, Mcbz, Rcbz))
        return;

    OrdenTrabajo o;

    o.estado = 1;

    do
    {
        puts("==========================================");
        puts("||                                      ||");
        puts("||======  Crear Orden de Trabajo  ======||");
        puts("||                                      ||");
        puts("==========================================\n");
        printf("Ingrese n%cmero de orden: ", 163);
        leerint(&o.numeroOrden);

        if(o.numeroOrden < 1 || o.numeroOrden > 32767)
            mensaje("Ingrese un numero valido (entre 1 y 32767)");
        else if(buscar_NumOrden(Ocbz, o.numeroOrden) >= 0)
        {
            mensaje("\nERROR: Este numero de orden ya existe elija otro por favor!");
            o.numeroOrden = -1;
        }
    }
    while(o.numeroOrden < 1 || o.numeroOrden > 32767);
    system("cls");

    do
    {
        puts("==========================================");
        puts("||                                      ||");
        puts("||======  Crear Orden de Trabajo  ======||");
        puts("||                                      ||");
        puts("==========================================\n");
        printf("Ingrese n%cmero de orden: %d\n", 163, o.numeroOrden);
        printf("Ingrese ID del vehiculo: ");
        leerint(&o.idVehiculo);
        if(o.idVehiculo < 1 || o.idVehiculo > 32767)
            mensaje("\nERROR: Ingrese un numero valido! (entre 1 y 32767)");
        else if(buscar_id_veh(Vcbz, o.idVehiculo) < 0)
        {
            mensaje("\nERROR: Este id de vehiculo no existe");
            o.idVehiculo = -1;
        }
        else if(buscar_Orden_idveh(Ocbz, o.idVehiculo) >= 0)
        {
            mensaje("\nERROR: Este vehiculo ya tiene una orden");
            o.idVehiculo = -1;
        }

    }
    while(o.idVehiculo < 1 || o.idVehiculo > 32767);
    system("cls");

    do
    {
        puts("==========================================");
        puts("||                                      ||");
        puts("||======  Crear Orden de Trabajo  ======||");
        puts("||                                      ||");
        puts("==========================================\n");
        printf("Ingrese n%cmero de orden: %d\n", 163, o.numeroOrden);
        printf("Ingrese ID del vehiculo: %d\n", o.idVehiculo);
        printf("Ingrese ID del cliente: ");
        leerint(&o.idCliente);
        if(o.idCliente < 1 || o.idCliente > 32767)
            mensaje("\nERROR: Ingrese un numero valido! (entre 1 y 32767)");
        else if(buscar_id_cl(Ccbz, o.idCliente) < 0)
        {
            mensaje("\nERROR: Este id de cliente no existe");
            o.idCliente = -1;
        }

    }
    while(o.idCliente < 1 || o.idCliente > 32767);
    system("cls");

    do
    {
        puts("==========================================");
        puts("||                                      ||");
        puts("||======  Crear Orden de Trabajo  ======||");
        puts("||                                      ||");
        puts("==========================================\n");
        printf("Ingrese n%cmero de orden: %d\n", 163, o.numeroOrden);
        printf("Ingrese ID del vehiculo: %d\n", o.idVehiculo);
        printf("Ingrese ID del cliente: %d\n", o.idCliente);
        printf("Ingrese ID del mecanico: ");
        leerint(&o.idMecanico);
        if(o.idMecanico < 1 || o.idMecanico > 32767)
            mensaje("\nERROR: Ingrese un numero valido! (entre 1 y 32767)");
        else if(buscar_id_mec(Mcbz, o.idMecanico) < 0)
        {
            mensaje("\nERROR: Este id de cliente no existe");
            o.idMecanico = -1;
        }

    }
    while(o.idMecanico < 1 || o.idMecanico > 32767);
    system("cls");

    do
    {
        puts("==========================================");
        puts("||                                      ||");
        puts("||======  Crear Orden de Trabajo  ======||");
        puts("||                                      ||");
        puts("==========================================\n");
        printf("Ingrese n%cmero de orden: %d\n", 163, o.numeroOrden);
        printf("Ingrese ID del vehiculo: %d\n", o.idVehiculo);
        printf("Ingrese ID del cliente: %d\n", o.idCliente);
        printf("Ingrese ID del mecanico: %d\n", o.idMecanico);
        printf("Ingrese fecha de ingreso (dia/mes/anio): ");
        if(scanf("%d/%d/%d", &o.fechaIngreso.dia, &o.fechaIngreso.mes, &o.fechaIngreso.anio) != 3)
        {
            mensaje("\nERROR: Tiene que escribir la fecha en el formato XX/XX/XXXX (ej. 05/05/2005)!");
            clean_teclado();
            continue;
        }
        else if(validar_fecha(o.fechaIngreso.dia, o.fechaIngreso.mes, o.fechaIngreso.anio))
        {
            mensaje("\nERROR: La fecha no es valida!");
            continue;
        }

        break;

    }
    while(1);
    system("cls");

    do
    {
        puts("==========================================");
        puts("||                                      ||");
        puts("||======  Crear Orden de Trabajo  ======||");
        puts("||                                      ||");
        puts("==========================================\n");
        printf("Ingrese n%cmero de orden: %d\n", 163, o.numeroOrden);
        printf("Ingrese ID del vehiculo: %d\n", o.idVehiculo);
        printf("Ingrese ID del cliente: %d\n", o.idCliente);
        printf("Ingrese ID del mecanico: %d\n", o.idMecanico);
        printf("Ingrese fecha de ingreso (dia/mes/anio): %d/%d/%d\n", o.fechaIngreso.dia, o.fechaIngreso.mes, o.fechaIngreso.anio );
        printf("Ingrese cantidad de repuestos a usar (max 10): ");
        leerint(&o.cantRepuestos);
        if(o.cantRepuestos < 1 || o.cantRepuestos > 10)
            mensaje("\nERROR: Ingrese un cantidad valida! (entre 1 y 10)");
    }
    while(o.cantRepuestos < 1 || o.cantRepuestos > 10);

    system("cls");

    elegir_repuestos(&o, Rcbz, o.cantRepuestos);

    int i;
    do
    {
        puts("==========================================");
        puts("||                                      ||");
        puts("||======  Crear Orden de Trabajo  ======||");
        puts("||                                      ||");
        puts("==========================================\n");
        printf("Ingrese n%cmero de orden: %d\n", 163, o.numeroOrden);
        printf("Ingrese ID del vehiculo: %d\n", o.idVehiculo);
        printf("Ingrese ID del cliente: %d\n", o.idCliente);
        printf("Ingrese ID del mecanico: %d\n", o.idMecanico);
        printf("Ingrese fecha de ingreso (dia/mes/anio): %d/%d/%d\n", o.fechaIngreso.dia, o.fechaIngreso.mes, o.fechaIngreso.anio );
        printf("Ingrese cantidad de repuestos a usar (max 10): %d\n\n", o.cantRepuestos);


        for(i = 0; i < o.cantRepuestos; i++)
        {
            printf("======  Repuesto %d  ======\n", i+1);
            printf("Ingrese ID del repuesto: %d\n", (o.listaRepuestos+i)->idRepuesto );
            printf("Ingrese nombre del repuesto: %s\n", (o.listaRepuestos+i)->nombre );
            printf("Ingrese cantidad: %d\n", (o.listaRepuestos+i)->cantidad );
            printf("Ingrese precio unitario: %.2f\n\n", (o.listaRepuestos+i)->precioUnitario );
        }

        printf("Ingrese costo de mano de obra: ");
        leerfloat(&o.costoManoObra);

        if(o.costoManoObra < 49.99 || o.costoManoObra > 5000.00)
            mensaje("\nERROR: El precio debe de estar entre 49.99 y maximo 5000.00!");
    }
    while(o.costoManoObra < 49.99 || o.costoManoObra > 5000.00);

    o.subtotal = 0;
    for(i = 0; i < o.cantRepuestos; i++)
        o.subtotal += (o.listaRepuestos+i)->subtotal;

    o.subtotal += o.costoManoObra;

    o.itbis = o.subtotal * 0.18;

    o.totalFinal = o.subtotal + o.itbis;

    if((*Ocl = Insertar_Nodo_Ord(Ocbz, Ocl, o)) == NULL)
    {
        mensaje("\nERROR: No se pudo crear la orden!");
    }
    else
    {
        FILE *Oach = fopen("OrdenesDeTrabajo.dat", "ab");
        if(Oach == NULL)
        {
            mensaje("\nError: No se pudo abrir el archivo de Ordenes  De Trabajo");
            return;
        }

        fwrite(&o, sizeof(OrdenTrabajo), 1, Oach);
        fclose(Oach);

        printf("Orden  capturada con %cxito. Estado inicial: Recibido\n", 130);
        printf("Subtotal: %.2f\n", o.subtotal);
        printf("ITBIS (18%): %.2f\n", o.itbis);
        printf("Total final: %.2f\n", o.totalFinal);
        mensaje("");
    }

}

/*
Nombre: LISTAR_ORDEN

Que hace: Calcula los anchos de columna necesarios segun los datos mas largos
          e imprime una tabla con todas las ordenes registradas, mostrando
          numero de orden, placa del vehiculo, nombre del cliente, estado y
          total final.

Que recibe: Ocbz -> puntero al puntero cabeza de la lista de ordenes,
            Ocl  -> puntero al puntero cola de la lista de ordenes (no se usa),
            Vcbz -> puntero al puntero cabeza de la lista de vehiculos,
            Ccbz -> puntero al puntero cabeza de la lista de clientes,
            Mcbz -> puntero al puntero cabeza de la lista de mecanicos (no se usa),
            Rcbz -> puntero al puntero cabeza de la lista de repuestos (no se usa).

Que retorna: No retorna nada (void); solo imprime la lista en pantalla.
*/
void LISTAR_ORDEN(Norden **Ocbz, Norden **Ocl, Nvehiculo **Vcbz, Ncliente **Ccbz, Nmecanico **Mcbz, Nrepuesto **Rcbz)
{
    if(*Ocbz == NULL)
    {
        mensaje("\nERROR: No hay Ordenes aun, por favor cree alguna!");
        return;
    }

    int TamID = 3;
    int TamVEH = 8;
    int TamCL = 15;
    int TamEST = 6;
    int TamTOT = 4;
    impresion_ord(Ocbz, Ccbz, &TamID, &TamCL, &TamEST, &TamTOT);

    puts("==================================");;
    puts("||                              ||");
    puts("||=====  Lista de Ordenes  =====||");
    puts("||                              ||");
    puts("==================================\n");
    printf("%-*s | %-*s | %-*s | %-*s | %-*s\n", TamID, "NO.",
           TamVEH, "VEHICULO",
           TamCL, "CLIENTE",
           TamEST, "ESTADO",
           TamTOT, "TOTAL");

    int i, j;
    for(i = 0, j = TamID + TamVEH+ TamCL + TamEST + TamTOT; i < 1.5*j; i++)
        printf("=");
    printf("\n");


    Norden *IND = *Ocbz;
    while(IND)
    {
        Nvehiculo *VEH = devolver_ind_veh(Vcbz, IND->ot.idVehiculo);
        Ncliente *CL = devolver_ind_cl(Ccbz, IND->ot.idCliente);

        printf("%-*d | %-*s | %-*s | %-*s | %-*.2f\n", TamID, IND->ot.numeroOrden,
               TamVEH, VEH->veh.placa,
               TamCL, CL->cl.nombre,
               TamEST, estado(IND->ot.estado),
               TamTOT, IND->ot.totalFinal);

        IND = IND->prox;
    }

    printf("\n");
    system("pause");
    system("cls");
}

/*
Nombre: DETALLAR_ORDEN

Que hace: Solicita un numero de orden, busca la orden correspondiente y
          muestra todos sus detalles: numero, vehiculo (marca, modelo, placa),
          cliente, mecanico, fecha de ingreso, estado, lista de repuestos
          utilizados con cantidades y precios, subtotal, ITBIS y total final.

Que recibe: Ocbz -> puntero al puntero cabeza de la lista de ordenes,
            Ocl  -> puntero al puntero cola de la lista de ordenes (no se usa),
            Vcbz -> puntero al puntero cabeza de la lista de vehiculos,
            Ccbz -> puntero al puntero cabeza de la lista de clientes,
            Mcbz -> puntero al puntero cabeza de la lista de mecanicos,
            Rcbz -> puntero al puntero cabeza de la lista de repuestos (solo para ajustar anchos).

Que retorna: No retorna nada (void); imprime el detalle en pantalla.
*/
void DETALLAR_ORDEN(Norden **Ocbz, Norden **Ocl, Nvehiculo **Vcbz, Ncliente **Ccbz, Nmecanico **Mcbz, Nrepuesto **Rcbz)
{
    if(*Ocbz == NULL)
    {
        mensaje("\nERROR: No hay ordenes aun, por favor cree alguna!");
        return;
    }

    int buscar, pos;
    printf("N%cmero de orden: ", 163);
    leerint(&buscar);

    if((pos = buscar_NumOrden(Ocbz, buscar)) < 0)
    {
        mensaje("El numero de orden no existe y/o no es valido");
        return;
    }

    system("cls");

    Norden *IND = *Ocbz;

    for(int i = 0; i < pos; i++)
        IND = IND->prox;

    Nvehiculo *VEH = devolver_ind_veh(Vcbz, IND->ot.idVehiculo);
    Ncliente *CL = devolver_ind_cl(Ccbz, IND->ot.idCliente);
    Nmecanico *MEC = devolver_ind_mec(Mcbz, IND->ot.idMecanico);

    puts("===============================================");
    puts("||                                           ||");
    puts("||======  Detalle de Orden de Trabajo  ======||");
    puts("||                                           ||");
    puts("===============================================\n");
    printf("Orden No: %d\n", IND->ot.numeroOrden);
    printf("Veh%cculo: %s %s (%s)\n", 161, VEH->veh.marca, VEH->veh.modelo, VEH->veh.placa);
    printf("Cliente: %s\n", CL->cl.nombre);
    printf("Mec%cnico: %s\n", 160, MEC->mec.nombre);
    printf("Fecha de ingreso: %d/%d/%d\n", IND->ot.fechaIngreso.dia, IND->ot.fechaIngreso.mes, IND->ot.fechaIngreso.anio );
    printf("Estado: %s\n", estado(IND->ot.estado));
    puts("Repuestos utilizados:");

    int TamID = 2;
    int TamNOM = 6;
    int TamCANT = 8;
    int TamPRE = 12;
    int TamSUB = 8;
    impresion_rep(Rcbz, &TamID, &TamNOM, &TamSUB);
    printf("%-*s  %-*s  %-*s  %-*s  %-*s\n", TamID, "ID",
           TamNOM, "NOMBRE",
           TamCANT, "CANTIDAD",
           TamPRE, "PRECIO UNIT.",
           TamSUB, "SUBTOTAL");

    int i, j;
    for(i = 0, j = TamID + TamNOM + TamCANT + TamPRE + TamSUB; i < 1.5*j; i++)
        printf("=");
    printf("\n");
    for(i = 0; i < IND->ot.cantRepuestos; i++)
    {
        printf("%-*d  %-*s  %-*d  %-*.2f  %-*.2f\n",TamID, (IND->ot.listaRepuestos+i)->idRepuesto,
               TamNOM, (IND->ot.listaRepuestos+i)->nombre,
               TamCANT, (IND->ot.listaRepuestos+i)->cantidad,
               TamPRE, (IND->ot.listaRepuestos+i)->precioUnitario,
               TamSUB, (IND->ot.listaRepuestos+i)->subtotal);
    }

    printf("Subtotal: %.2f\n", IND->ot.subtotal);
    printf("ITBIS (18%): %.2f\n", IND->ot.itbis);
    printf("Total final: %.2f\n", IND->ot.totalFinal);
    mensaje("");
}

/*
Nombre: CAMBIAR_ESTADO_ORDEN

Que hace: Solicita un numero de orden y, si la orden no esta entregada,
          avanza su estado al siguiente (siguiendo el flujo: Recibido → En
          Diagnostico → En Reparacion → Listo → Entregado). Pide confirmacion
          al usuario y actualiza el archivo en disco.

Que recibe: Ocbz -> puntero al puntero cabeza de la lista de ordenes,
            Ocl  -> puntero al puntero cola de la lista de ordenes (no se usa).

Que retorna: No retorna nada (void); modifica el estado de la orden en
             memoria y en el archivo.
*/
void CAMBIAR_ESTADO_ORDEN(Norden **Ocbz, Norden **Ocl)
{
    if(*Ocbz == NULL)
    {
        mensaje("\nERROR: No hay ordenes aun, por favor cree alguna!");
        return;
    }

    int buscar, pos;
    printf("N%cmero de orden: ", 163);

    leerint(&buscar);

    if((pos = buscar_NumOrden(Ocbz, buscar)) < 0)
    {
        mensaje("El numero de orden no existe y/o no es valido");
        return;
    }

    Norden *IND = *Ocbz;

    for(int i = 0; i < pos; i++)
        IND = IND->prox;

    if(IND->ot.estado == 5)
    {
        mensaje("Esta orden ya se encuentra entregada asi que no se puede cambiar de estado!");
        return;
    }
    else
    {
        char eleccion;
        do
        {
            printf("Estado actual: %s\n", estado(IND->ot.estado));
            printf("Siguiente estado disponible: %s\n",estado(IND->ot.estado+1));
            printf("Confirma el cambio de estado? (S/N): ");

            elige(&eleccion);
            if(eleccion == 'N')
            {
                mensaje("\nNO se cambio de estado!");
                return;
            }
        }
        while(eleccion != 'S' && eleccion != 'N');

        FILE *Oach = fopen("OrdenesDeTrabajo.dat", "r+b");
        if(Oach == NULL)
        {
            mensaje("\nERROR: Para abrir el archivo de ordenes!");
            return;
        }

        IND->ot.estado += 1;
        OrdenTrabajo o = IND->ot;
        fseek(Oach, pos * sizeof(OrdenTrabajo), SEEK_SET);
        fwrite(&o, sizeof(OrdenTrabajo), 1, Oach);
        fclose(Oach);
        printf("Orden actualizada a estado: %s\n", estado(IND->ot.estado));
        system("pause");
        system("cls");
    }
}

/*
Nombre: ANULAR_ORDEN

Que hace: Solicita un numero de orden y, si la orden esta en estado Recibido
          (1) o En Diagnostico (2), la anula (cambia a estado 0). Pide
          confirmacion al usuario y actualiza el archivo en disco. No permite
          anular ordenes en estados posteriores (En Reparacion, Listo, Entregado).

Que recibe: Ocbz -> puntero al puntero cabeza de la lista de ordenes,
            Ocl  -> puntero al puntero cola de la lista de ordenes (no se usa).

Que retorna: No retorna nada (void); modifica el estado de la orden en
             memoria y en el archivo.
*/
void ANULAR_ORDEN(Norden **Ocbz, Norden **Ocl)
{
    if(*Ocbz == NULL)
    {
        mensaje("\nERROR: No hay ordenes aun, por favor cree alguna!");
        return;
    }

    int buscar, pos;
    printf("N%cmero de orden: ", 163);
    leerint(&buscar);

    if((pos = buscar_NumOrden(Ocbz, buscar)) < 0)
    {
        mensaje("El numero de orden no existe y/o no es valido");
        return;
    }

    Norden *IND = *Ocbz;
    for(int i = 0; i < pos; i++)
        IND = IND->prox;

    if(IND->ot.estado == 0)
    {
        mensaje("La orden ya se encuentra anulada");
        return;
    }
    else if(IND->ot.estado > 2)
    {
        mensaje("No se puede anular: la orden ya supero el estado permitido para anulacion (Recibido / En Diagnostico)!");
        return;
    }
    else
    {
        char eleccion;
        do
        {
            printf("Estado actual: %s\n", estado(IND->ot.estado));
            printf("Siguiente estado: %s\n",estado(0));
            printf("Confirma la anulacion de la orden? (S/N): ");

            elige(&eleccion);
            if(eleccion == 'N')
            {
                mensaje("\nNO se cambio de estado!");
                return;
            }
        }
        while(eleccion != 'S' && eleccion != 'N');

        FILE *Oach = fopen("OrdenesDeTrabajo.dat", "r+b");
        if(Oach == NULL)
        {
            mensaje("\nERROR: Para abrir el archivo de ordenes!");
            return;
        }

        IND->ot.estado = 0;
        OrdenTrabajo o = IND->ot;
        fseek(Oach, pos * sizeof(OrdenTrabajo), SEEK_SET);
        fwrite(&o, sizeof(OrdenTrabajo), 1, Oach);
        fclose(Oach);
        printf("Orden actualizada a estado: %s\n", estado(IND->ot.estado));
        system("pause");
        system("cls");
    }
}

/*
Nombre: Insertar_Nodo_Ord

Que hace: Reserva memoria para un nuevo nodo de orden, copia la estructura
          OrdenTrabajo en el y lo engancha al final de la lista doblemente
          enlazada (o como primer nodo si la lista estaba vacia).

Que recibe: Ocbz -> puntero al puntero cabeza de la lista de ordenes,
            Ocl  -> puntero al puntero cola de la lista de ordenes,
            o    -> estructura OrdenTrabajo ya validada que se quiere agregar.

Que retorna: Puntero al nodo nuevo (que pasa a ser la nueva cola), o NULL
             si no se pudo reservar memoria.
*/
Norden *Insertar_Nodo_Ord(Norden **Ocbz, Norden **Ocl, OrdenTrabajo o)
{
    Norden *no = (Norden *) calloc(1, sizeof(Norden));

    if(no == NULL)
    {
        printf("no se pudo asignar la memoria :(");
        return NULL;
    }

    no->ot = o;
    no->prox = NULL;
    no->ant = *Ocl;

    if(*Ocbz == NULL)
        *Ocbz = no;
    else if(*Ocl)
        (*Ocl)->prox = no;

    return no;
}

/*
Nombre: free_ot

Que hace: Recorre toda la lista de ordenes liberando cada nodo con free.

Que recibe: Ocbz -> puntero al primer nodo de la lista de ordenes (cabeza).

Que retorna: No retorna nada (void).
*/
void free_ot(Norden *Ocbz)
{
    Norden *IND = Ocbz;
    while(Ocbz)
    {
        IND = Ocbz->prox;
        free(Ocbz);
        Ocbz = IND;
    }

}
