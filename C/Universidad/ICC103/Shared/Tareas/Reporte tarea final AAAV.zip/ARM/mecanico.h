#ifndef mecanico_H
#define mecanico_H
#include "structs.h"

void leer_arch_mec(Nmecanico **Mcbz, Nmecanico **Mcl);
int buscar_id_mec(Nmecanico **Mcbz, int referencia);
void CRUD_mec(Nmecanico **Mcbz, Nmecanico **Mcl, Norden **Ocbz);
void CREATE_MECANICO(Nmecanico **Mcbz, Nmecanico **Mcl);
void  READ_MECANICO(Nmecanico **Mcbz, Nmecanico **Mcl);
void   UPDATE_MECANICO(Nmecanico **Mcbz, Nmecanico **Mcl, Norden **Ocbz);
void    DISABLE_MECANICO(Nmecanico **Mcbz, Nmecanico **Mcl, Norden **Ocbz);
Nmecanico *Insertar_Nodo_Mec(Nmecanico **Mcbz, Nmecanico **Mcl, Mecanico m);
void free_mec(Nmecanico *Mcbz);

#endif
