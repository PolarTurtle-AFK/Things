#ifndef OrdenTrabajo_H
#define OrdenTrabajo_H
#include "structs.h"

void leer_arch_ot(Norden **Ocbz, Norden **Ocl);
int buscar_NumOrden(Norden **Ocbz, int referencia);
int buscar_Orden_idmec(Norden **Ocbz, int referencia);
int buscar_Orden_idcl(Norden **Ocbz, int referencia);
int buscar_Orden_idveh(Norden **Ocbz, int referencia);
int buscar_Orden_idrep(Norden **Ocbz, int referencia, int *lugar);
void ORDEN(Norden **Ocbz, Norden **Ocl, Nvehiculo **Vcbz, Ncliente **Ccbz, Nmecanico **Mcbz, Nrepuesto **Rcbz);
void CREAR_ORDEN(Norden **Ocbz, Norden **Ocl, Nvehiculo **Vcbz, Ncliente **Ccbz, Nmecanico **Mcbz, Nrepuesto **Rcbz);
void LISTAR_ORDEN(Norden **Ocbz, Norden **Ocl, Nvehiculo **Vcbz, Ncliente **Ccbz, Nmecanico **Mcbz, Nrepuesto **Rcbz);
void DETALLAR_ORDEN(Norden **Ocbz, Norden **Ocl, Nvehiculo **Vcbz, Ncliente **Ccbz, Nmecanico **Mcbz, Nrepuesto **Rcbz);
void CAMBIAR_ESTADO_ORDEN(Norden **Ocbz, Norden **Ocl);
void ANULAR_ORDEN(Norden **Ocbz, Norden **Ocl);
Norden *Insertar_Nodo_Ord(Norden **Ocbz, Norden **Ocl, OrdenTrabajo o);
void free_ot(Norden *Ocbz);

#endif
