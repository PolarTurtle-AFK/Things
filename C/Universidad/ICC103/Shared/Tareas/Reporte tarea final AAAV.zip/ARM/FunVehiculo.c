#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "vehiculo.h"
#include "proyecto.h"

/*
Nombre: leer_arch_veh

Que hace: Abre (o crea si no existe) vehiculos.dat y carga cada registro
          guardado en disco como un nodo nuevo de la lista de vehiculos.

Que recibe: Vcbz -> Nodo vehiculo cabeza,
            Ccl -> Nodo vehiculo cola.

Que retorna: No retorna nada (void), deja la lista cargada en memoria.
*/
void leer_arch_veh(Nvehiculo **Vcbz, Nvehiculo **Vcl)
{
    Vehiculo v;

    FILE *Vach = fopen("vehiculos.dat", "rb");

    if(Vach == NULL)
    {
        Vach = fopen("vehiculos.dat", "ab");
        if(Vach == NULL)
        {
            puts("no se pudo crear el archivo de Vehiculo :(");
            exit(1);
        }
    }
    else
        while(fread(&v, sizeof(Vehiculo), 1, Vach))
            *Vcl = Insertar_Nodo_Veh(Vcbz, Vcl, v);

    fclose(Vach);
}

/*
Nombre: buscar_id_veh

Que hace: Recorre la lista de vehiculos comparando el id de cada nodo con
          el id buscado.

Que recibe: Vcbz -> Nodo vehiculo cabeza,
            referencia -> id que se busca.

Que retorna: La posicion (indice desde 0) del vehiculo si lo encuentra,
             o -1 si ningun vehiculo tiene ese id.
*/
int buscar_id_veh(Nvehiculo **Vcbz, int referencia)
{
    Nvehiculo *IND = *Vcbz;
    int cont = 0;
    while(IND)
    {
        if(IND->veh.id == referencia)
            return cont;
        else
            cont++;

        IND = IND->prox;
    }

    return -1;
}

/*
Nombre: buscar_placa_veh

Que hace: Recorre la lista de vehiculos compararndo las placas con la referencia buscada.

Que recibe: Vcbz -> Nodo vehiculo cabeza,
            referencia -> placa que se busca.

Que retorna: La posicion (indice desde 0) del vehiculo si lo encuentra,
             o -1 si ningun vehiculo tiene ese id.
*/
int buscar_placa_veh(Nvehiculo **Vcbz, char *referencia)
{
    Nvehiculo *IND = *Vcbz;
    int cont = 0;
    while(IND)
    {
        if(strcasecmp(IND->veh.placa, referencia) == 0)
            return cont;
        else
            cont++;

        IND = IND->prox;
    }

    return -1;
}

/*
Nombre: CRUD_veh

Que hace: Muestra el submenu de Vehiculos (crear, listar, modificar,
          borrar/desactivar) y llama a la funcion correspondiente segun
          la opcion elegida.

Que recibe: Vcbz -> Nodo vehiculo cabeza,
            Vcl -> Nodo vehiculo cola,
            Ocbz -> Nodo orden cabeza (para saber si un vehiculo tiene
            ordenes al editar/borrar).

Que retorna: No retorna nada (void); se mantiene en el submenu hasta que
             el usuario elige volver (0).
*/
void CRUD_veh(Nvehiculo **Vcbz, Nvehiculo **Vcl, Norden **Ocbz)
{
    int op;
    do
    {
        puts("+------------------------------+");
        puts("|                              |");
        printf("|====== MEN%c DE VEH%cCULOS =====|\n", 233, 214);
        puts("|                              |");
        puts("+------------------------------+\n");
        puts("+------------------------------+");
        printf("| 1. Crear veh%cculo            |\n", 161);
        printf("| 2. Listar veh%cculos          |\n", 161);
        printf("| 3. Modificar veh%cculo        |\n", 161);
        printf("| 4. Borrar/Desactivar veh%cculo|\n", 161);
        puts("| 0. Volver                    |");
        puts("+------------------------------+");
        printf("Seleccione una opci%cn: ", 162);

        leerint(&op);

        switch(op)
        {
        case 1:
            system("cls");
            CREATE_VEHICULO(Vcbz, Vcl);
            break;

        case 2:
            system("cls");
            READ_VEHICULO(Vcbz, Vcl);
            break;

        case 3:
            system("cls");
            UPDATE_VEHICULO(Vcbz, Vcl, Ocbz);
            break;

        case 4:
            system("cls");
            DISABLE_VEHICULO(Vcbz, Vcl, Ocbz);
            break;

        case 0:
            system("cls");
            break;

        default:
            mensaje("\nERROR: Tienes que ingresar un numero de las opciones que se muestran!");
            break;
        }
    }
    while(op != 0);
}

/*
Nombre: CREATE_VEHICULO

Que hace: Pide id, placa, marca, modelo y a�o validando cada dato (id unico y
          en rango, placa unica, ect.), arma un
          vehiculo activo, lo inserta en la lista y lo agrega al final de
          mecanicos.dat.

Que recibe: Vcbz -> Nodo vehiculo cabeza,
            Vcl -> Nodo vehiculo cola.

Que retorna: No retorna nada (void); deja el nuevo vehiculo creado en
             memoria.
*/
void CREATE_VEHICULO(Nvehiculo **Vcbz, Nvehiculo **Vcl)
{
    Vehiculo v;

    v.activo = 1;

    do
    {
        puts("=================================");
        puts("||                             ||");
        printf("||==  Creador de Veh%cculos   ==||\n", 161);
        puts("||                             ||");
        puts("=================================\n");
        printf("Ingrese id del vehiculo (1-32767): ");
        leerint(&v.id);

        if(v.id < 1 || v.id > 32767)
            mensaje("\nERROR: Ingrese un numero valido! (entre 1 y 32767)");
        else if(buscar_id_veh(Vcbz, v.id) >= 0)
        {
            mensaje("\nERROR: Este id ya existe elija otro por favor!");
            v.id = -1;
        }

    }
    while(v.id < 1 || v.id > 32767);
    system("cls");

    do
    {
        puts("=================================");
        puts("||                             ||");
        printf("||==  Creador de Veh%cculos   ==||\n", 161);
        puts("||                             ||");
        puts("=================================\n");
        printf("Ingrese id del vehiculo (1-32767): %d\n", v.id);
        printf("Ingrese placa (ej. A12345/AB1234): ");
        fgets(v.placa, 10, stdin);
        limpiar_salto(v.placa);
        if(*(v.placa) != '\n')
            if(validar_placa(v.placa))
                *(v.placa) = '\n';
            else if(buscar_placa_veh(Vcbz, v.placa) >= 0)
            {
                mensaje("\nERROR: Esta placa ya existe elija otra!");
                *(v.placa) = '\n';
            }
    }
    while(*(v.placa) == '\n');
    system("cls");

    do
    {
        puts("=================================");
        puts("||                             ||");
        printf("||==  Creador de Veh%cculos   ==||\n", 161);
        puts("||                             ||");
        puts("=================================\n");
        printf("Ingrese id del vehiculo (1-32767): %d\n", v.id);
        printf("Ingrese placa (ej. A12345/AB1234): %s\n", v.placa);
        printf("Ingrese marca: ");
        fgets(v.marca, 30, stdin);
        limpiar_salto(v.marca);
    }
    while(*(v.marca) == '\n');
    system("cls");

    do
    {
        puts("=================================");
        puts("||                             ||");
        printf("||==  Creador de Veh%cculos   ==||\n", 161);
        puts("||                             ||");
        puts("=================================\n");
        printf("Ingrese id del vehiculo (1-32767): %d\n", v.id);
        printf("Ingrese placa (ej. A12345/AB1234): %s\n", v.placa);
        printf("Ingrese marca: %s\n", v.marca);
        printf("Ingrese modelo: ");
        fgets(v.modelo, 30, stdin);
        limpiar_salto(v.modelo);
    }
    while(*(v.modelo) == '\n');
    system("cls");

    do
    {
        puts("=================================");
        puts("||                             ||");
        printf("||==  Creador de Veh%cculos   ==||\n", 161);
        puts("||                             ||");
        puts("=================================\n");
        printf("Ingrese id del vehiculo (1-32767): %d\n", v.id);
        printf("Ingrese placa (ej. A12345/AB1234): %s\n", v.placa);
        printf("Ingrese marca: %s\n", v.marca);
        printf("Ingrese modelo: %s\n", v.modelo);
        printf("Ingrese a%co: ", 164);
        leerint(&v.anio);

        if(v.anio < 1970 || v.anio > 2026)
        {
            printf("\nERROR: El a%co debe de estar entre 1970 y 2026!\n", 164);
            system("pause");
            system("cls");
        }

    }
    while(v.anio < 1970 || v.anio > 2026);

    if((*Vcl = Insertar_Nodo_Veh(Vcbz, Vcl, v)) == NULL)
    {
        mensaje("\nERROR: No se pudo crear el vehiculo!");
    }
    else
    {
        FILE *Vach = fopen("vehiculos.dat", "ab");
        if(Vach == NULL)
        {
            mensaje("\nError: No se pudo abrir el archivo de vehiculos!");
            return;
        }

        fwrite(&v, sizeof(Vehiculo), 1, Vach);
        fclose(Vach);

        mensaje("\nSe creo el vehiculo!");
    }

}

/*
Nombre: READ_VEHICULO

Que hace: Se le va pidiendo al usuario que rellene todos lo datos y cuando termina se crea un nodo y se guarda en el archivo.

Que recibe: Vcbz -> Nodo vehiculo cabeza,
            Vcl -> "" cola.

Que retorna: No retorna nada (void).
*/
void READ_VEHICULO(Nvehiculo **Vcbz, Nvehiculo **Vcl)
{
    if(*Vcbz == NULL)
    {
        mensaje("\nERROR: No hay autos aun, por favor cree alguno!");
        return;
    }

    int TamID = 2;
    int TamPLA = 6;
    int TamMAR = 5;
    int TamMOD = 6;
    int TamANIO = 4;
    impresion_veh(Vcbz, &TamID, &TamMAR, &TamMOD);

    Nvehiculo *IND = *Vcbz;
    puts("==================================");;
    puts("||                              ||");
    printf("||====  Lista de Veh%cculos  ====||\n", 161);
    puts("||                              ||");
    puts("==================================\n");
    printf("%-*s | %-*s | %-*s | %-*s | %c%c%-*s\n", TamID, "ID",
           TamPLA, "PLACA",
           TamMAR, "MARCA",
           TamMOD, "MODELO",
           'A', 165, TamANIO, "O");

    int i, j;
    for(i = 0, j = TamID + TamPLA + TamMAR + TamMOD + TamANIO; i < 1.5*j; i++)
        printf("=");
    printf("\n");


    while(IND)
    {
        printf("%-*d | %-*s | %-*s | %-*s | %-*d\n", TamID, IND->veh.id,
               TamPLA, IND->veh.placa,
               TamMAR, IND->veh.marca,
               TamMOD, IND->veh.modelo,
               TamANIO, IND->veh.anio);

        IND = IND->prox;
    }

    printf("\n");
    system("pause");
    system("cls");
}

/*
Nombre: UPDATE_VEHICULO

Que hace: Busca el mecanico por id, muestra un submenu para elegir que
          campo modificar (repite hasta que el usuario presiona X), pide
          confirmacion y, si se confirma, actualiza el nodo en memoria y
          el registro en mecanicos.dat. Si el id cambio, actualiza tambien
          las ordenes que lo referencian.

Que recibe: Vcbz -> Nodo mecanico cabeza,
            Vcl -> Nodo mecanico cola,
            Ocbz -> Nodo orden cabeza (para el cambio de id).

Que retorna: No retorna nada (void).
*/
void UPDATE_VEHICULO(Nvehiculo **Vcbz, Nvehiculo **Vcl, Norden **Ocbz)
{
    if(*Vcbz == NULL)
    {
        mensaje("\nERROR: No hay autos aun, por favor cree alguno!");
        return;
    }

    int buscar, pos;
    printf("Ingrese el id del vehiculo a buscar: ");
    leerint(&buscar);
    if((pos = buscar_id_veh(Vcbz, buscar)) < 0)
    {
        mensaje("El ID no existe y/o no es valido");
        return;
    }

    system("cls");

    Vehiculo v;
    Nvehiculo *IND = *Vcbz;
    for(int i = 0; i < pos; i++)
        IND = IND->prox;

    v = IND->veh;

    char eleccion;

    do
    {
        puts("==================================");;
        puts("||                              ||");
        printf("||====  Modificar Veh%cculo  ====||\n", 161);
        puts("||                              ||");
        puts("==================================");
        printf("1. ID: %d\n", v.id);
        printf("2. Placa: %s\n", v.placa);
        printf("3. Marca: %s\n", v.marca);
        printf("4. Modelo: %s\n", v.modelo);
        printf("5. Anio: %d\n", v.anio);
        printf("6. Estado: %s\n", v.activo == 1 ? "Activo" : "Inactivo");
        printf("X. Salir\n\n");
        printf("Seleccione una opcion: ");
        eleccion = getchar();
        if(eleccion != '\n')
            clean_teclado();

        switch(eleccion)
        {
        case '1':
            system("cls");
            do
            {
                printf("Ingrese el nuevo id del vehiculo: ");
                leerint(&v.id);

                if(v.id < 1 || v.id > 32767)
                {
                    mensaje("\nERROR: Ingrese un numero valido! (entre 1 y 32767)");
                    v.id = -1;
                }
                else if(buscar_id_veh(Vcbz, v.id) >= 0)
                {
                    mensaje("\nERROR: Este id ya existe elija otro por favor!");
                    v.id = -1;
                }
            }
            while(v.id < 1 || v.id > 32767);
            system("cls");
            break;

        case '2':
            system("cls");
            do
            {
                printf("Ingrese la nueva placa: ");
                fgets(v.placa, 10, stdin);
                limpiar_salto(v.placa);

                if(*(v.placa) != '\n')
                    if(validar_placa(v.placa))
                        *(v.placa) = '\n';
                    else if(buscar_placa_veh(Vcbz, v.placa) >= 0)
                    {
                        mensaje("\nERROR: Esta placa ya existe elija otra!");
                        *(v.placa) = '\n';
                    }
            }
            while(*(v.placa) == '\n');
            system("cls");
            break;

        case '3':
            system("cls");
            do
            {
                printf("Ingrese la nueva marca: ");
                fgets(v.marca, 30, stdin);
                limpiar_salto(v.marca);
            }
            while(*(v.marca) == '\n');
            system("cls");
            break;

        case '4':
            system("cls");
            do
            {
                printf("Ingrese el nuevo modelo: ");
                fgets(v.modelo, 30, stdin);
                limpiar_salto(v.modelo);
            }
            while(*(v.modelo) == '\n');
            system("cls");
            break;

        case '5':
            system("cls");
            do
            {
                printf("Ingrese el nuevo a%co: ", 164);
                leerint(&v.anio);

                if(v.anio < 1970 || v.anio > 2026)
                {
                    printf("\nERROR: El a%co debe de estar entre 1970 y 2026!\n", 164);
                    system("pause");
                    system("cls");
                }
            }
            while(v.anio < 1970 || v.anio > 2026);
            system("cls");
            break;

        case '6':
            system("cls");
            do
            {
                printf("Quieres cambiar de estado de %s a %s? (S/N): ", v.activo == 1 ? "Activo" : "Inactivo", v.activo == 1 ? "Inactivo" : "Activo");
                elige(&eleccion);
                if(eleccion == 'S')
                {
                    if(v.activo == 1)
                        v.activo = 0;
                    else
                        v.activo = 1;

                    mensaje("Se cambio de estado!");
                }
            }
            while(eleccion != 'S' && eleccion != 'N');
            system("cls");
            break;

        case 'x':
        case 'X':
            system("cls");
            break;

        default:
            mensaje("\nERROR: Tienes que ingresar una de las opciones que se muestran!");
            break;
        }
    }
    while(eleccion != 'x' && eleccion != 'X');

    do
    {
        puts("==================================");;
        puts("||                              ||");
        printf("||====  Modificar Veh%cculo  ====||\n", 161);
        puts("||                              ||");
        puts("==================================");
        printf("ID: %d\n", v.id);
        printf("Placa: %s\n", v.placa);
        printf("Marca: %s\n", v.marca);
        printf("Modelo: %s\n", v.modelo);
        printf("A%co: %d\n", 164, v.anio);
        printf("Estado: %s\n", v.activo == 1 ? "Activo" : "Inactivo");
        printf("Quiere guardar los cambios? (S/N): ");
        elige(&eleccion);
        if(eleccion == 'N')
        {
            mensaje("\nNo se guardaron los cambios!");
            return;
        }
    }
    while(eleccion != 'S' && eleccion != 'N');

    FILE *Vach = fopen("vehiculos.dat", "r+b");
    if(Vach == NULL)
    {
        mensaje("\nError: para leer o abrir el archivo de vehiculos!");
        return;
    }

    IND->veh = v;
    fseek(Vach, pos * sizeof(Vehiculo), SEEK_SET);
    fwrite(&v, sizeof(Vehiculo), 1, Vach);
    fclose(Vach);
    if(buscar != v.id)
        actualizar_id_veh_en_ordenes(Ocbz, buscar, v.id);

    mensaje("\nSe guardaron los cambios correctamente!");
}

/*
Nombre: DISABLE_VEHICULO

Que hace: Busca el vehiculo por id y, tras confirmar con el usuario, si el
          vehiculo ya tiene alguna orden asignada solo lo marca como
          inactivo; si nunca tuvo ordenes lo elimina por completo de la
          lista y de vehiculos.dat.

Que recibe: vcbz -> Nodo vehiculo cabeza,
            Vcl -> Nodo vehiculo cola,
            Ocbz -> Nodo orden cabeza (para saber si el vehiculo tiene ordenes).

Que retorna: No retorna nada (void).
*/
void DISABLE_VEHICULO(Nvehiculo **Vcbz, Nvehiculo **Vcl, Norden **Ocbz)
{
    if(*Vcbz == NULL)
    {
        mensaje("\nERROR: No hay autos aun, por favor cree alguno!");
        return;
    }

    int buscar, pos;
    printf("Ingrese el id del vehiculo a buscar: ");
    leerint(&buscar);
    if((pos = buscar_id_veh(Vcbz, buscar)) < 0)
    {
        mensaje("El ID No existe y/o no es valido");
        return;
    }
    system("cls");

    Nvehiculo *IND = *Vcbz;
    for(int i = 0; i < pos; i++)
        IND = IND->prox;

    if(IND->veh.activo == 0)
    {
        mensaje("\nERROR: El vehiculo ya se encuentra desactivado si desea activarlo vaya a modificar!");
        return;
    }
    else
    {
        char eleccion;

        do
        {
            puts("=================================");
            puts("||                             ||");
            printf("|| Borrar/Desactivar Veh%cculos ||\n", 161);
            puts("||                             ||");
            puts("=================================");
            printf("ID: %d\n", IND->veh.id);
            printf("Placa: %s\n", IND->veh.placa);
            printf("Marca: %s\n", IND->veh.marca);
            printf("Modelo: %s\n", IND->veh.modelo);
            printf("A%co: %d\n\n", 164, IND->veh.anio);
            printf("Quieres borrar/desactivar este vehiculo? (S/N): ");
            elige(&eleccion);
            if(eleccion == 'N')
            {
                mensaje("\nEl vehiculo no fue borrado/desactivado!");
                return;
            }
        }
        while(eleccion != 'S' && eleccion != 'N');
    }

    FILE *Vach = fopen("vehiculos.dat", "r+b");
    if(Vach == NULL)
    {
        mensaje("\nError: No se pudo leer o abrir el archivo de vehiculos!");
        return;
    }

    Vehiculo v;
    if(buscar_Orden_idveh(Ocbz, buscar) >= 0)
    {
        //Inactivarlo
        IND->veh.activo = 0;
        v = IND->veh;
        fseek(Vach, pos * sizeof(Vehiculo), SEEK_SET);
        fwrite(&v, sizeof(Vehiculo), 1, Vach);
        fclose(Vach);
        mensaje("\nEl vehiculo ya tiene una Orden activa asi que solo se desactivo!");
    }
    else
    {
        //Borrarlo completamente
        FILE *temp = fopen("temp.dat", "wb");
        if(temp == NULL)
        {
            mensaje("\nError: no se pudo abrir el archivo temporal de vehiculos!");
            return;
        }

        if(IND->ant)
            IND->ant->prox = IND->prox;
        else
            *Vcbz = IND->prox;

        if(IND->prox)
            IND->prox->ant = IND->ant;
        else
            *Vcl = IND->ant;

        free(IND);

        while(fread(&v, sizeof(Vehiculo), 1, Vach))
            if(v.id != buscar)
                fwrite(&v, sizeof(Vehiculo), 1, temp);

        fclose(Vach);
        fclose(temp);

        remove("vehiculos.dat");
        rename("temp.dat", "vehiculos.dat");
        mensaje("\nVehiculo borrado correctamente!");
    }
}

/*
Nombre: Insertar_Nodo_VEH

Que hace: Reserva memoria para un nodo nuevo, copia el vehiculo dentro y lo
          engancha al final de la lista doblemente enlazada (o como primer
          nodo si la lista estaba vacia).

Que recibe: Vcbz -> Nodo vehiculo cabeza,
            Vcl -> Nodo vehiculo cola,
            v -> struct vehiculo ya validado que se quiere agregar.

Que retorna: Puntero al nodo nuevo (que pasa a ser la nueva cola), o NULL
             si no se pudo reservar memoria.
*/
Nvehiculo *Insertar_Nodo_Veh(Nvehiculo **Vcbz, Nvehiculo **Vcl, Vehiculo v)
{
    Nvehiculo *nv = (Nvehiculo *) calloc(1, sizeof(Nvehiculo));

    if(nv == NULL)
    {
        printf("\nERROR: No se pudo asignar la memoria para el nodo");
        return NULL;
    }

    nv->veh = v;
    nv->prox = NULL;
    nv->ant = *Vcl;

    if(*Vcbz == NULL)
        *Vcbz = nv;
    else if(*Vcl)
        (*Vcl)->prox = nv;

    return nv;
}

/*
Nombre: free_veh

Que hace: Recorre toda la lista de cleintes liberando cada nodo con free.

Que recibe: Ccbz -> Nodo cleinte cabeza (primer nodo de la lista).

Que retorna: No retorna nada (void).
*/
void free_veh(Nvehiculo *Vcbz)
{
    Nvehiculo *IND = Vcbz;
    while(Vcbz)
    {
        IND = Vcbz->prox;
        free(Vcbz);
        Vcbz = IND;
    }
}
