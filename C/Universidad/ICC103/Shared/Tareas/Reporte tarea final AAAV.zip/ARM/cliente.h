#ifndef cliente_H
#define cliente_H
#include "structs.h"

void leer_arch_cl(Ncliente **Ccbz, Ncliente **Ccl);
int buscar_id_cl(Ncliente **Ccbz, int referencia);
void CRUD_cl(Ncliente **Ccbz, Ncliente **Ccl, Norden **Ocbz);
void CREATE_CLIENTE(Ncliente **Ccbz, Ncliente **Ccl);
void  READ_CLIENTE(Ncliente **Ccbz, Ncliente **Ccl);
void   UPDATE_CLIENTE(Ncliente **Ccbz, Ncliente **Ccl, Norden **Ocbz);
void    DISABLE_CLIENTE(Ncliente **Ccbz, Ncliente **Ccl, Norden **Ocbz);
Ncliente *Insertar_Nodo_Cl(Ncliente **Ccbz, Ncliente **Ccl, Cliente c);
void free_cl(Ncliente *Ccbz);

#endif
