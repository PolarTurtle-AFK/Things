#include <stdio.h>
#include <stdlib.h>
#include "proyecto.h"

/*
Nombre: clean_teclado

Que hace: Limpia el buffer del teclado leyendo y descartando todos los
          caracteres hasta encontrar un salto de linea o el final del archivo.

Que recibe: No recibe parametros.

Que retorna: No retorna nada (void).
*/
void clean_teclado()
{
    int ch;
    while((ch = getchar()) != '\n' && ch != EOF);
}

/*
Nombre: leerint

Que hace: Lee un numero entero desde la entrada estandar. Si la lectura
          falla (no se ingreso un numero valido), asigna -1 al entero
          apuntado. Luego limpia el buffer del teclado.

Que recibe: c -> puntero a int donde se almacenara el valor leido.

Que retorna: No retorna nada (void).
*/
void leerint(int *c)
{
    if(scanf("%d", c) != 1)
        *c = -1;

    clean_teclado();
}

/*
Nombre: limpiar_salto

Que hace: Elimina el salto de linea ('\n') de una cadena leida con fgets.
          Si la cadena esta vacia (solo '\n'), muestra un mensaje de error.
          Si el usuario ingreso mas caracteres de los que caben en el buffer,
          limpia el excedente del buffer.

Que recibe: s -> puntero a la cadena a procesar.

Que retorna: No retorna nada (void).
*/
void limpiar_salto(char *s)
{
    int i, c;
    if(*s == '\n')
    {
        mensaje("\nERROR: Debes de ingresar algo!");
        return;
    }

    for(i = 0; *(s+i) != '\n' && *(s+i) != '\0'; i++);

    if(*(s+i) == '\n')
        *(s+i) = '\0';
    else
        clean_teclado();
}

/*
Nombre: mensaje

Que hace: Muestra un mensaje en pantalla, hace una pausa (system("pause"))
          y limpia la consola (system("cls")).

Que recibe: s -> puntero a la cadena de texto que se mostrara.

Que retorna: No retorna nada (void).
*/
void mensaje(char *s)
{
    puts(s);
    system("pause");
    system("cls");
}

/*
Nombre: validar_fecha

Que hace: Verifica si una fecha (dia, mes, a�o) es valida. El a�o debe ser
          >= 1900, el mes entre 1 y 12, y el dia entre 1 y el numero de dias
          del mes correspondiente (considerando a�os bisiestos).

Que recibe: dia, mes, anio -> enteros que representan la fecha.

Que retorna: 1 si la fecha NO es valida, 0 si es valida.
*/
int validar_fecha(int dia, int mes, int anio)
{
    if(anio < 1900)
        return 1;
    else if(mes < 1 || mes > 12)
        return 1;
    else if(dia < 1 || dia > num_dia(mes, anio))
        return 1;

    return 0;
}

/*
Nombre: num_dia

Que hace: Devuelve el numero de dias que tiene un mes determinado, teniendo
          en cuenta si el a�o es bisiesto para el mes de febrero.

Que recibe: mes, anio -> enteros que indican el mes (1-12) y el a�o.

Que retorna: El numero de dias (28, 29, 30 o 31).
*/
int num_dia(int mes, int anio)
{
    if(mes == 4 || mes == 6 || mes == 9 || mes == 11)
        return 30;

    if(mes == 2)
        if(esBisiesto(anio))
            return 29;
        else
            return 28;

    return 31;
}

/*
Nombre: esBisiesto

Que hace: Determina si un a�o es bisiesto segun la regla: divisible entre 4,
          excepto los divisibles entre 100, a menos que tambien sean
          divisibles entre 400.

Que recibe: anio -> entero que representa el a�o.

Que retorna: 1 si es bisiesto, 0 en caso contrario.
*/
int esBisiesto(int anio)
{
    if((anio%4 == 0 && anio%100 != 0) || (anio%400 == 0))
        return 1;

    return 0;
}

/*
Nombre: validar_placa

Que hace: Valida el formato de una placa vehicular. Debe tener 6 caracteres:
          el primero una letra, el segundo una letra o numero, y los ultimos
          4 numeros. Convierte las letras a mayusculas.

Que recibe: s -> puntero a la cadena de la placa.

Que retorna: 1 si la placa NO es valida, 0 si es valida.
*/
int validar_placa(char *s)
{
    if(strlen(s) != 6)
    {
        mensaje("\nERROR: La placa debe de contener 6 caracteres!");
        return 1;
    }
    else if((*s < 'A' || *s > 'Z') && (*s < 'a' || *s > 'z'))
    {
        mensaje("\nERROR: Al menos el primer caracter debe ser una letra!");
        return 1;
    }
    else if((*(s+1) < 'A' || *(s+1) > 'Z') && (*(s+1) < 'a' || *(s+1) > 'z') && (*(s+1) < '0' || *(s+1) > '9'))
    {
        mensaje("\nERROR: El segundo caracter tiene que ser una letra o un numero!");
        return 1;
    }

    int i;
    for(i = 2; *(s+i) != '\0'; i++)
        if(*(s+i) < '0' || *(s+i) > '9')
        {
            mensaje("\nERROR: Los ultimos 4 caracteres tienen que ser numeros!");
            return 1;
        }

    if(*s >= 'a' && *s <= 'z')
        *s -= 32;
    if(*(s+1) >= 'a' && *(s+1) <= 'z')
        *(s+1) -= 32;

    return 0;
}

/*
Nombre: contar_dig

Que hace: Cuenta el numero de digitos de un entero positivo usando recursion.

Que recibe: n -> entero positivo.

Que retorna: El numero de digitos de n, o 0 si n < 1.
*/
int contar_dig(int n)
{
    if(n < 1)
        return 0;

    return 1 + contar_dig(n/10);
}

/*
Nombre: impresion_veh

Que hace: Recorre la lista de vehiculos y actualiza los tama�os de columna
          (ancho maximo) para ID, marca y modelo segun los datos mas largos.

Que recibe: Vcbz -> puntero al puntero cabeza de la lista de vehiculos,
            TamID, TamMAR, TamMOD -> punteros a enteros que se actualizaran.

Que retorna: No retorna nada (void).
*/
void impresion_veh(Nvehiculo **Vcbz, int *TamID, int *TamMAR, int *TamMOD)
{
    Nvehiculo *IND = *Vcbz;

    while(IND)
    {
        int DIG = contar_dig(IND->veh.id);
        int MAR = strlen(IND->veh.marca);
        int MOD = strlen(IND->veh.modelo);


        if(DIG > *TamID)
            *TamID = DIG;

        if(MAR > *TamMAR)
            *TamMAR = MAR;

        if(MOD > *TamMOD)
            *TamMOD = MOD;

        IND = IND->prox;
    }
}

/*
Nombre: elige

Que hace: Lee un caracter del teclado, limpia el buffer, convierte a
          mayuscula si es 's' o 'n', y si no es 'S' ni 'N' muestra un mensaje.

Que recibe: eleccion -> puntero a char donde se almacenara la opcion.

Que retorna: No retorna nada (void).
*/
void elige(char *eleccion)
{
    *eleccion = getchar();

    if(*eleccion != '\n')
        clean_teclado();

    if(*eleccion == 's' || *eleccion == 'n')
        *eleccion -= 32;

    if(*eleccion != 'S' && *eleccion != 'N')
        mensaje("Elija entre S o N!");
}

/*
Nombre: validar_nombre

Que hace: Valida un nombre de persona (cliente, mecanico). Solo permite
          letras, espacios y guiones. No permite espacios dobles, ni empezar
          con espacio o guion. Debe contener al menos un espacio (nombre y
          apellido). Convierte la primera letra de cada palabra a mayuscula.

Que recibe: s -> puntero a la cadena a validar.

Que retorna: 1 si NO es valido, 0 si es valido.
*/
int validar_nombre(char *s)
{

    if(*s == ' ' || *s == '-')
    {
        mensaje("\nERROR: El nombre no puede empezar con guion o espacio!");
        return 1;
    }

    int i, separar;
    for(i = 0, separar = 1; *(s+i) != '\0'; i++)
    {
        if((*(s+i) < 'A' || *(s+i) > 'Z') && (*(s+i) < 'a' || *(s+i) > 'z') && *(s+i) != ' ' && *(s+i) != '-')
        {
            mensaje("\nERROR: Solo se permiten letras, guion y espacio!");
            return 1;
        }

        if(*(s+i) == ' ')
            separar = 0;
    }

    if(separar)
    {
        mensaje("\nERROR: Debe ingresar un nombre y apellido separados por un espacio!");
        return 1;
    }

    for(i = 0; *(s+i) != '\0'; i++)
        if(*(s+i) == ' ' && *(s+i+1) == ' ')
        {
            mensaje("\nERROR: No puede haber espacios dobles!");
            return 1;
        }

    *s = (*s >= 'a' && *s <= 'z') ? *s - 32 : *s;
    for(i = 1; *(s+i) != '\0'; i++)
        if(*(s+i-1) == ' ' || *(s+i-1) == '-')
            if(*(s+i) >= 'a' && *(s+i) <= 'z')
                *(s+i) -= 32;

    return 0;
}

/*
Nombre: validar_telefono

Que hace: Valida un numero de telefono con el formato XXX-XXX-XXXX (12
          caracteres). Los guiones deben estar en las posiciones 3 y 7,
          y el resto deben ser digitos.

Que recibe: s -> puntero a la cadena del telefono.

Que retorna: 1 si NO es valido, 0 si es valido.
*/
int validar_telefono(char *s)
{
    if(strlen(s) != 12)
    {
        mensaje("\nERROR: El telefono debe tener 12 caracteres (ej. 809-555-1234)!!");
        return 1;
    }

    int i;
    for(i = 0; *(s+i) != '\0'; i++)
    {
        if(i == 3 || i == 7)
        {
            if(*(s+i) != '-')
            {
                mensaje("\nERROR: El formato debe ser XXX-XXX-XXXX (ej. 809-555-1234)!");
                return 1;
            }
        }
        else if(*(s+i) < '0' || *(s+i) > '9')
        {
            mensaje("\nERROR: Solo se permiten numeros en las posiciones que no son guion!");
            return 1;
        }

    }

    return 0;

}

/*
Nombre: buscar_nombre_cl

Que hace: Busca un nombre de cliente en la lista (insensible a mayusculas/
          minusculas). Recorre la lista y devuelve la posicion si encuentra
          coincidencia.

Que recibe: Ccbz -> puntero al puntero cabeza de la lista de clientes,
            referencia -> puntero a la cadena a buscar.

Que retorna: La posicion (indice) del cliente si existe, o -1 si no.
*/
int buscar_nombre_cl(Ncliente **Ccbz, char *referencia)
{
    Ncliente *IND = *Ccbz;
    int cont = 0;
    while(IND)
    {
        if(strcasecmp(IND->cl.nombre, referencia) == 0)
            return cont;
        else
            cont++;

        IND = IND->prox;
    }

    return -1;
}

/*
Nombre: buscar_telefono_cl

Que hace: Busca un telefono de cliente en la lista (comparacion exacta con
          strcmp). Recorre la lista y devuelve la posicion si encuentra
          coincidencia.

Que recibe: Ccbz -> puntero al puntero cabeza de la lista de clientes,
            referencia -> puntero a la cadena a buscar.

Que retorna: La posicion (indice) del cliente si existe, o -1 si no.
*/
int buscar_telefono_cl(Ncliente **Ccbz, char *referencia)
{
    Ncliente *IND = *Ccbz;
    int cont = 0;
    while(IND)
    {
        if(strcmp(IND->cl.telefono, referencia) == 0)
            return cont;
        else
            cont++;

        IND = IND->prox;
    }

    return -1;
}

/*
Nombre: impresion_cl

Que hace: Recorre la lista de clientes y actualiza los tama�os de columna
          (ancho maximo) para ID y nombre segun los datos mas largos.

Que recibe: Ccbz -> puntero al puntero cabeza de la lista de clientes,
            TamID, TamNOM -> punteros a enteros que se actualizaran.

Que retorna: No retorna nada (void).
*/
void impresion_cl(Ncliente **Ccbz, int *TamID, int *TamNOM)
{
    Ncliente *IND = *Ccbz;

    while(IND)
    {
        int NOM = strlen(IND->cl.nombre);
        int DIG = contar_dig(IND->cl.id);

        if(NOM > *TamNOM)
            *TamNOM = NOM;

        if(DIG > *TamID)
            *TamID = DIG;

        IND = IND->prox;
    }
}

/*
Nombre: buscar_nombre_mec

Que hace: Busca un nombre de mecanico en la lista (insensible a mayusculas/
          minusculas). Recorre la lista y devuelve la posicion si encuentra
          coincidencia.

Que recibe: Mcbz -> puntero al puntero cabeza de la lista de mecanicos,
            referencia -> puntero a la cadena a buscar.

Que retorna: La posicion (indice) del mecanico si existe, o -1 si no.
*/
int buscar_nombre_mec(Nmecanico **Mcbz, char *referencia)
{
    Nmecanico *IND = *Mcbz;
    int cont = 0;
    while(IND)
    {
        if(strcasecmp(IND->mec.nombre, referencia) == 0)
            return cont;
        else
            cont++;

        IND = IND->prox;
    }

    return -1;
}

/*
Nombre: impresion_mec

Que hace: Recorre la lista de mecanicos y actualiza los tama�os de columna
          (ancho maximo) para ID, nombre y especialidad segun los datos
          mas largos.

Que recibe: Mcbz -> puntero al puntero cabeza de la lista de mecanicos,
            TamID, TamNOM, TamESP -> punteros a enteros que se actualizaran.

Que retorna: No retorna nada (void).
*/
void impresion_mec(Nmecanico **Mcbz, int *TamID, int *TamNOM, int *TamESP)
{
    Nmecanico *IND = *Mcbz;

    while(IND)
    {
        int NOM = strlen(IND->mec.nombre);
        int DIG = contar_dig(IND->mec.id);
        int ESP = strlen(IND->mec.especialidad);;

        if(NOM > *TamNOM)
            *TamNOM = NOM;

        if(DIG > *TamID)
            *TamID = DIG;

        if(ESP > *TamESP)
            *TamESP = ESP;

        IND = IND->prox;
    }
}

/*
Nombre: validar_nombre_rep

Que hace: Valida un nombre de repuesto. Solo permite letras, espacios y
          guiones. No permite espacios dobles ni empezar con espacio o guion.
          Convierte la primera letra de cada palabra a mayuscula.

Que recibe: s -> puntero a la cadena a validar.

Que retorna: 1 si NO es valido, 0 si es valido.
*/
int validar_nombre_rep(char *s)
{
    if(*s == ' ' || *s == '-')
    {
        mensaje("\nERROR: El nombre no puede empezar con guion o espacio!");
        return 1;
    }

    int i;
    for(i = 0; *(s+i) != '\0'; i++)
        if((*(s+i) < 'A' || *(s+i) > 'Z') && (*(s+i) < 'a' || *(s+i) > 'z') && *(s+i) != ' ' && *(s+i) != '-')
        {
            mensaje("\nERROR: Solo se permiten letras, guion y espacio!");
            return 1;
        }
        else if(*(s+i) == ' ' && *(s+i+1) == ' ')
        {
            mensaje("\nERROR: No puede haber espacios dobles!");
            return 1;
        }

    *s = (*s >= 'a' && *s <= 'z') ? *s - 32 : *s;
    for(i = 1; *(s+i) != '\0'; i++)
        if(*(s+i-1) == ' ' || *(s+i-1) == '-')
            if(*(s+i) >= 'a' && *(s+i) <= 'z')
                *(s+i) -= 32;

    return 0;
}

/*
Nombre: buscar_nombre_rep

Que hace: Busca un nombre de repuesto en la lista (insensible a mayusculas/
          minusculas). Recorre la lista y devuelve la posicion si encuentra
          coincidencia.

Que recibe: Rcbz -> puntero al puntero cabeza de la lista de repuestos,
            referencia -> puntero a la cadena a buscar.

Que retorna: La posicion (indice) del repuesto si existe, o -1 si no.
*/
int buscar_nombre_rep(Nrepuesto **Rcbz, char *referencia)
{
    Nrepuesto *IND = *Rcbz;
    int cont = 0;
    while(IND)
    {
        if(strcasecmp(IND->rep.nombre, referencia) == 0)
            return cont;
        else
            cont++;

        IND = IND->prox;
    }

    return -1;
}

/*
Nombre: leerfloat

Que hace: Lee un numero flotante desde la entrada estandar. Si la lectura
          falla (no es un numero valido), asigna -1.0 al flotante apuntado.
          Luego limpia el buffer del teclado.

Que recibe: c -> puntero a float donde se almacenara el valor.

Que retorna: No retorna nada (void).
*/
void leerfloat(float *c)
{
    if(scanf("%f", c) != 1)
        *c = -1.0;

    clean_teclado();
}

/*
Nombre: impresion_rep

Que hace: Recorre la lista de repuestos y actualiza los tama�os de columna
          (ancho maximo) para ID, nombre y subtotal segun los datos mas largos.

Que recibe: Rcbz -> puntero al puntero cabeza de la lista de repuestos,
            TamID, TamNOM, TamSUB -> punteros a enteros que se actualizaran.

Que retorna: No retorna nada (void).
*/
void impresion_rep(Nrepuesto **Rcbz,  int *TamID, int *TamNOM, int *TamSUB)
{
    Nrepuesto *IND = *Rcbz;

    while(IND)
    {
        int DIG = contar_dig(IND->rep.idRepuesto);
        int NOM = strlen(IND->rep.nombre);
        int SUB = contar_dig((int)IND->rep.subtotal) + 3;

        if(DIG > *TamID)
            *TamID = DIG;

        if(NOM > *TamNOM)
            *TamNOM = NOM;

        if(SUB > *TamSUB)
            *TamSUB = SUB;

        IND = IND->prox;
    }
}

/*
Nombre: verificar

Que hace: Verifica que existan al menos un vehiculo, un cliente, un mecanico
          activo y al menos un repuesto con stock > 0 para poder crear una
          orden de trabajo. Si falta algo, muestra mensaje y retorna 1.

Que recibe: Vcbz, Ccbz, Mcbz, Rcbz -> punteros a las cabezas de las listas.

Que retorna: 1 si no se puede crear la orden, 0 si todo esta listo.
*/
int verificar(Nvehiculo **Vcbz, Ncliente **Ccbz, Nmecanico **Mcbz, Nrepuesto **Rcbz)
{
    if(*Vcbz == NULL)
    {
        mensaje("\nERROR: No hay vehiculos para poder crear una orden!");
        return 1;
    }
    else if(*Ccbz == NULL)
    {
        mensaje("\nERROR: No hay Clientes para poder crear una orden!");
        return 1;
    }
    else if(*Mcbz == NULL)
    {
        mensaje("\nERROR: No hay Mecanicos para poder crear una orden!");
        return 1;
    }
    else if(*Rcbz == NULL)
    {
        mensaje("\nERROR: No hay Repuestos para poder crear una orden!");
        return 1;
    }

    Nmecanico *IND = *Mcbz;
    while(IND)
    {
        if(IND->mec.activo == 1)
            return 0;

        IND = IND->prox;
    }

    mensaje("\nERROR: No hay Mecanicos Activos para poder crear una orden!");
    return 1;

}

/*
Nombre: stock_repuestos

Que hace: Recorre la lista de repuestos y retorna 1 si al menos uno tiene
          cantidad > 0, de lo contrario retorna 0.

Que recibe: Rcbz -> puntero al puntero cabeza de la lista de repuestos.

Que retorna: 1 si hay stock, 0 si no hay.
*/
int stock_repuestos(Nrepuesto **Rcbz)
{
    Nrepuesto *IND = *Rcbz;

    while(IND)
    {
        if(IND->rep.cantidad > 0)
            return 1;

        IND = IND->prox;
    }

    return 0;
}

/*
Nombre: seguir_eligiendo

Que hace: Verifica si aun hay repuestos con stock > 0 que no hayan sido
          seleccionados previamente en la orden. Se usa durante la seleccion
          de repuestos para saber si se puede seguir agregando.

Que recibe: Rcbz -> puntero a la lista de repuestos,
            elegidos -> arreglo de IDs ya seleccionados,
            cant_elegidos -> cantidad de IDs en el arreglo.

Que retorna: 1 si hay al menos un repuesto disponible y no seleccionado,
             0 en caso contrario.
*/
int seguir_eligiendo(Nrepuesto **Rcbz, int *elegidos, int cant_elegidos)
{
    Nrepuesto *IND = *Rcbz;

    while(IND)
    {
        int elegido = 1;
        for(int i = 0; i < cant_elegidos; i++)
            if(*(elegidos + i) == IND->rep.idRepuesto)
            {
                elegido = 0;
                break;
            }

        if(elegido && IND->rep.cantidad > 0)
        {
            return 1;
        }

        IND = IND->prox;
    }

    return 0;
}

/*
Nombre: elegir_repuestos

Que hace: Permite al usuario seleccionar hasta n repuestos para una orden.
          Muestra la lista de repuestos disponibles (con stock), valida
          que no se repitan, pide cantidad a usar y actualiza el stock
          en la lista y en la orden (OT). Si no hay suficientes repuestos,
          ajusta la cantidad real de repuestos de la orden.

Que recibe: OT -> puntero a la estructura OrdenTrabajo donde se guardaran
                   los repuestos seleccionados,
            Rcbz -> puntero a la lista de repuestos,
            n -> numero maximo de repuestos a elegir.

Que retorna: No retorna nada (void), pero modifica OT y las cantidades
             de los repuestos en la lista.
*/
void elegir_repuestos(OrdenTrabajo *OT, Nrepuesto **Rcbz, int n)
{
    int i, j, op;
    int *elegidos = (int *) calloc(1, sizeof(int));
    int cant_elegidos = 0;
    int usado;

    Nrepuesto *IND;
    for(i = 0; i < n; i++)
    {
        do
        {
            IND = *Rcbz;
            printf("RESPUESTO %d\n", i+1);
            while(IND)
            {
                usado = 1;
                for(j = 0; j < cant_elegidos; j++)
                {
                    if(*(elegidos + j) == IND->rep.idRepuesto)
                    {
                        usado = 0;
                        break;
                    }
                }

                if(IND->rep.cantidad > 0 && usado)
                    printf("ID: %d | Nombre: %s | Precio: %.2f | Cantidad: %d\n", IND->rep.idRepuesto, IND->rep.nombre, IND->rep.precioUnitario, IND->rep.cantidad);

                IND = IND->prox;
            }

            printf("\nIngrese id del repuesto (1-32767): ");
            leerint(&op);
            if(op < 1 || op > 32767)
                mensaje("\nERROR: Ingrese un numero valido! (entre 1 y 32767)");
            else if(buscar_id_rep(Rcbz, op) < 0)
            {
                mensaje("\nERROR: Este id de repuesto no existe");
                op = -1;
                continue;
            }

            usado = 0;
            for(j = 0; j < cant_elegidos; j++)
            {
                if(*(elegidos + j) == op)
                {
                    usado = 1;
                    break;
                }
            }

            if(usado)
            {
                mensaje("\nERROR: Este repuesto ya fue seleccionado en esta orden!");
                op = -1;
                continue;
            }

            IND = *Rcbz;
            while(IND->rep.idRepuesto != op)
                IND = IND->prox;

            if(IND->rep.cantidad < 1)
            {
                mensaje("\nERROR: La cantidad debe ser mayor a 0 y no superar el stock disponible.");
                op = -1;
            }

        }
        while(op < 1 || op > 32767);

        system("cls");

        do
        {
            printf("ID: %d | Nombre: %s | Precio: %.2f | Cantidad: %d\n", IND->rep.idRepuesto, IND->rep.nombre, IND->rep.precioUnitario, IND->rep.cantidad);
            printf("\nIngrese la cantidad a usar: ");
            leerint(&op);
            if(op < 1 || op > IND->rep.cantidad)
            {
                mensaje("\nERROR: Debe ser una cantidad no mayor a la disponible");
                op = -1;
            }

        }
        while(op < 1 || op > IND->rep.cantidad);


        *(OT->listaRepuestos + i) = IND->rep;
        (OT->listaRepuestos + i)->cantidad = op;
        (OT->listaRepuestos + i)->subtotal = op * (OT->listaRepuestos + i)->precioUnitario;

        IND->rep.cantidad -= op;
        IND->rep.subtotal = IND->rep.cantidad * IND->rep.precioUnitario;

        *(elegidos+cant_elegidos++) = IND->rep.idRepuesto;
        elegidos = (int *) realloc(elegidos, cant_elegidos * sizeof(int));

        if(!seguir_eligiendo(Rcbz, elegidos, cant_elegidos) && i != n - 1)
        {
            mensaje("\nERROR: Ya no hay mas repuestos disponibles");

            OT->cantRepuestos = i + 1;

            free(elegidos);
            return;
        }

        system("cls");

    }

    free(elegidos);

}

/*
Nombre: impresion_ord

Que hace: Recorre la lista de ordenes y actualiza los tama�os de columna
          (ancho maximo) para numero de orden, cliente, estado y total,
          segun los datos mas largos. Utiliza devolver_ind_cl para obtener
          el nombre del cliente.

Que recibe: Ocbz -> puntero a la lista de ordenes,
            Ccbz -> puntero a la lista de clientes,
            TamID, TamCL, TamEST, TamTOT -> punteros a enteros a actualizar.

Que retorna: No retorna nada (void).
*/
void impresion_ord(Norden **Ocbz, Ncliente **Ccbz, int *TamID, int *TamCL, int *TamEST, int *TamTOT)
{
    Norden *IND = *Ocbz;

    while(IND)
    {
        int DIG = contar_dig(IND->ot.numeroOrden);


        Ncliente *CL = devolver_ind_cl(Ccbz, IND->ot.idCliente);

        int NOM = strlen(CL->cl.nombre);

        int EST = (strlen(estado(IND->ot.estado)));

        int TOT = contar_dig((int)IND->ot.totalFinal) + 3;

        if(DIG > *TamID)
            *TamID = DIG;

        if(NOM > *TamCL)
            *TamCL = NOM;

        if(EST > *TamEST)
            *TamEST = EST;

        if(TOT > *TamTOT)
            *TamTOT = TOT;

        IND = IND->prox;
    }

}

/*
Nombre: estado

Que hace: Devuelve una cadena de texto que representa el estado de una
          orden segun su codigo numerico (0 = Anulada, 1 = Recibido,
          2 = En Diagnostico, 3 = En Reparacion, 4 = Listo, 5 = Entregado).

Que recibe: n -> entero con el codigo de estado (0-5).

Que retorna: Puntero a una cadena literal con el nombre del estado,
             o "ERROR" si el codigo no es valido.
*/
char *estado(int n)
{
    switch(n)
    {
    case 1:
        return "Recibido";
        break;

    case 2:
        return "En Diagnostico";
        break;

    case 3:
        return "En Reparacion";
        break;

    case 4:
        return "Listo";
        break;

    case 5:
        return "Entregado";
        break;

    case 0:
        return "Anulada";
        break;

    default:
        return "ERROR";
        break;

    }
}

/*
Nombre: devolver_ind_veh

Que hace: Busca un vehiculo por ID en la lista y devuelve un puntero al
          nodo que lo contiene.

Que recibe: Vcbz -> puntero al puntero cabeza de la lista de vehiculos,
            referencia -> ID del vehiculo a buscar.

Que retorna: Puntero al nodo del vehiculo, o NULL si no se encuentra.
*/
Nvehiculo *devolver_ind_veh(Nvehiculo **Vcbz, int referencia)
{
    Nvehiculo *IND = *Vcbz;
    while(IND)
    {
        if(IND->veh.id == referencia)
            return IND;

        IND = IND->prox;
    }

    return NULL;
}

/*
Nombre: devolver_ind_cl

Que hace: Busca un cliente por ID en la lista y devuelve un puntero al
          nodo que lo contiene.

Que recibe: Ccbz -> puntero al puntero cabeza de la lista de clientes,
            referencia -> ID del cliente a buscar.

Que retorna: Puntero al nodo del cliente, o NULL si no se encuentra.
*/
Ncliente *devolver_ind_cl(Ncliente **Ccbz, int referencia)
{
    Ncliente *IND = *Ccbz;
    while(IND)
    {
        if(IND->cl.id == referencia)
            return IND;

        IND = IND->prox;
    }

    return NULL;
}

/*
Nombre: devolver_ind_mec

Que hace: Busca un mecanico por ID en la lista y devuelve un puntero al
          nodo que lo contiene.

Que recibe: Mcbz -> puntero al puntero cabeza de la lista de mecanicos,
            referencia -> ID del mecanico a buscar.

Que retorna: Puntero al nodo del mecanico, o NULL si no se encuentra.
*/
Nmecanico *devolver_ind_mec(Nmecanico **Mcbz, int referencia)
{
    Nmecanico *IND = *Mcbz;
    while(IND)
    {
        if(IND->mec.id == referencia)
            return IND;

        IND = IND->prox;
    }

    return NULL;
}

/*
Nombre: devolver_ind_rep

Que hace: Busca un repuesto por ID en la lista y devuelve un puntero al
          nodo que lo contiene.

Que recibe: Rcbz -> puntero al puntero cabeza de la lista de repuestos,
            referencia -> ID del repuesto a buscar.

Que retorna: Puntero al nodo del repuesto, o NULL si no se encuentra.
*/
Nrepuesto *devolver_ind_rep(Nrepuesto **Rcbz, int referencia)
{
    Nrepuesto *IND = *Rcbz;
    while(IND)
    {
        if(IND->rep.idRepuesto == referencia)
            return IND;

        IND = IND->prox;
    }

    return NULL;
}

/*
Nombre: actualizar_id_veh_en_ordenes

Que hace: Actualiza el ID de vehiculo en todas las ordenes que tengan el
          ID viejo, reemplazandolo por el nuevo. Escribe el cambio en el
          archivo de ordenes.

Que recibe: Ocbz -> puntero a la lista de ordenes,
            id_viejo -> ID actual del vehiculo,
            id_nuevo -> nuevo ID a asignar.

Que retorna: No retorna nada (void).
*/
void actualizar_id_veh_en_ordenes(Norden **Ocbz, int id_viejo, int id_nuevo)
{
    Norden *IND = *Ocbz;
    int cont = 0;
    while(IND)
    {
        if(IND->ot.idVehiculo == id_viejo)
        {
            IND->ot.idVehiculo = id_nuevo;
            break;
        }

        cont++;
        IND = IND->prox;
    }

    FILE *Oach = fopen("OrdenesDeTrabajo.dat", "r+b");
    if(Oach == NULL)
    {
        mensaje("\nERROR: Para abrir el archivo de ordenes!");
        return;
    }

    OrdenTrabajo o = IND->ot;
    fseek(Oach, cont * sizeof(OrdenTrabajo), SEEK_SET);
    fwrite(&o, sizeof(OrdenTrabajo), 1, Oach);
    fclose(Oach);
    printf("Orden actualizada a estado: %s", estado(IND->ot.estado));
    system("pause");
    system("cls");

}

/*
Nombre: actualizar_id_cl_en_ordenes

Que hace: Actualiza el ID de cliente en todas las ordenes que tengan el
          ID viejo, reemplazandolo por el nuevo. Escribe el cambio en el
          archivo de ordenes.

Que recibe: Ocbz -> puntero a la lista de ordenes,
            id_viejo -> ID actual del cliente,
            id_nuevo -> nuevo ID a asignar.

Que retorna: No retorna nada (void).
*/
void actualizar_id_cl_en_ordenes(Norden **Ocbz, int id_viejo, int id_nuevo)
{
    Norden *IND = *Ocbz;
    int cont = 0;
    while(IND)
    {
        if(IND->ot.idCliente == id_viejo)
        {
            IND->ot.idCliente = id_nuevo;
            FILE *Oach = fopen("OrdenesDeTrabajo.dat", "r+b");
            if(Oach == NULL)
            {
                mensaje("\nERROR: Para abrir el archivo de ordenes!");
                return;
            }

            OrdenTrabajo o = IND->ot;
            fseek(Oach, cont * sizeof(OrdenTrabajo), SEEK_SET);
            fwrite(&o, sizeof(OrdenTrabajo), 1, Oach);
            fclose(Oach);
            printf("Orden actualizada a estado: %s", estado(IND->ot.estado));
            system("pause");
            system("cls");
        }

        cont++;
        IND = IND->prox;
    }

}

/*
Nombre: actualizar_id_mec_en_ordenes

Que hace: Actualiza el ID de mecanico en todas las ordenes que tengan el
          ID viejo, reemplazandolo por el nuevo. Escribe el cambio en el
          archivo de ordenes.

Que recibe: Ocbz -> puntero a la lista de ordenes,
            id_viejo -> ID actual del mecanico,
            id_nuevo -> nuevo ID a asignar.

Que retorna: No retorna nada (void).
*/
void actualizar_id_mec_en_ordenes(Norden **Ocbz, int id_viejo, int id_nuevo)
{
    Norden *IND = *Ocbz;
    int cont = 0;
    while(IND)
    {
        if(IND->ot.idMecanico == id_viejo)
        {
            IND->ot.idMecanico = id_nuevo;
            FILE *Oach = fopen("OrdenesDeTrabajo.dat", "r+b");
            if(Oach == NULL)
            {
                mensaje("\nERROR: Para abrir el archivo de ordenes!");
                return;
            }

            OrdenTrabajo o = IND->ot;
            fseek(Oach, cont * sizeof(OrdenTrabajo), SEEK_SET);
            fwrite(&o, sizeof(OrdenTrabajo), 1, Oach);
            fclose(Oach);
            printf("Orden actualizada a estado: %s", estado(IND->ot.estado));
            system("pause");
            system("cls");
        }

        cont++;
        IND = IND->prox;
    }
}

