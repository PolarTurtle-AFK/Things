#ifndef vehiculo_H
#define vehiculo_H
#include "structs.h"

void leer_arch_veh(Nvehiculo **Vcbz, Nvehiculo **Vcl);
int buscar_id_veh(Nvehiculo **Vcbz, int referencia);
int buscar_placa_veh(Nvehiculo **Vcbz, char *referencia);
void CRUD_veh(Nvehiculo **Vcbz, Nvehiculo **Vcl, Norden **Ocbz);
void CREATE_VEHICULO(Nvehiculo **Vcbz, Nvehiculo **Vcl);
void  READ_VEHICULO(Nvehiculo **Vcbz, Nvehiculo **Vcl);
void   UPDATE_VEHICULO(Nvehiculo **Vcbz, Nvehiculo **Vcl, Norden **Ocbz);
void    DISABLE_VEHICULO(Nvehiculo **Vcbz, Nvehiculo **Vcl, Norden **Ocbz);
Nvehiculo *Insertar_Nodo_Veh(Nvehiculo **Vcbz, Nvehiculo **Vcl, Vehiculo v);
void free_veh(Nvehiculo *Vcbz);

#endif
