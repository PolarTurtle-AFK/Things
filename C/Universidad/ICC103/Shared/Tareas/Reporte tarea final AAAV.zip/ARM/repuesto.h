#ifndef repuesto_H
#define repuesto_H
#include "structs.h"

void leer_arch_rep(Nrepuesto **Rcbz, Nrepuesto **Rcl);
int buscar_id_rep(Nrepuesto **Rcbz, int referencia);
void CRUD_rep(Nrepuesto **Rcbz, Nrepuesto **Rcl, Norden **Ocbz);
void CREATE_REPUESTO(Nrepuesto **Rcbz, Nrepuesto **Rcl);
void  READ_REPUESTO(Nrepuesto **Rcbz, Nrepuesto **Rcl);
void   UPDATE_REPUESTO(Nrepuesto **Rcbz, Nrepuesto **Rcl);
void    DISABLE_REPUESTO(Nrepuesto **Rcbz, Nrepuesto **Rcl, Norden **Ocbz);

Nrepuesto *Insertar_Nodo_Rep(Nrepuesto **Rcbz, Nrepuesto **Rcl, Repuesto r);

void free_rep(Nrepuesto *Rcbz);

#endif
