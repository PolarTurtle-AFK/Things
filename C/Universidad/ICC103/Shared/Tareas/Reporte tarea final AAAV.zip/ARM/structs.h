#ifndef structs_H
#define structs_H

typedef struct
{
    int id;
    char placa[10]; // Ej: "A123456"
    char marca[30];
    char modelo[30];
    int anio;
    int activo; // 1 = activo, 0 = inactivo
} Vehiculo;

typedef struct NodoV
{
    Vehiculo veh;
    struct NodoV *prox;
    struct NodoV *ant;
} Nvehiculo;

typedef struct
{
    int id;
    char nombre[50]; // solo letras, guion y espacio
    char telefono[15];
    int activo; // 1 = activo, 0 = inactivo
} Cliente;

typedef struct NodoC
{
    Cliente cl;
    struct NodoC *prox;
    struct NodoC *ant;
} Ncliente;

typedef struct
{
    int id;
    char nombre[50]; // solo letras, guion y espacio
    char especialidad[30]; // Ej: "Motor", "Frenos", "Electricidad"
    int activo; // 1 = activo, 0 = inactivo
} Mecanico;

typedef struct NodoM
{
    Mecanico mec;
    struct NodoM *prox;
    struct NodoM *ant;
} Nmecanico;

typedef struct
{
    int dia, mes, anio;
} Fecha;

typedef struct
{
    int idRepuesto;
    char nombre[40];
    int cantidad;
    float precioUnitario;
    float subtotal;
} Repuesto;

typedef struct NodoR
{
    Repuesto rep;
    struct NodoR *prox;
    struct NodoR *ant;
} Nrepuesto;

typedef struct
{
    int numeroOrden;
    int idVehiculo;
    int idCliente;
    int idMecanico;
    Fecha fechaIngreso;
    int cantRepuestos; // cantidad de repuestos usados
    Repuesto listaRepuestos[10];
    float costoManoObra;
    float subtotal;
    float itbis; // 18% del subtotal
    float totalFinal;
    int estado; // 1=Recibido,2=EnDiagnostico,3=EnReparacion,4=Listo,5=Entregado,0=Anulada
} OrdenTrabajo;

typedef struct NodoO
{
    OrdenTrabajo ot;
    struct NodoO *prox;
    struct NodoO *ant;
} Norden;

#endif
