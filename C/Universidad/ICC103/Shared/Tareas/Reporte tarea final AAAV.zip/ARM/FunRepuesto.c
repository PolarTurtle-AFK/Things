#include <stdio.h>
#include <stdlib.h>
#include "repuesto.h"
#include "proyecto.h"

/*
Nombre: leer_arch_rep

Que hace: Abre (o crea si no existe) repuestos.dat y carga cada registro
          guardado en disco como un nodo nuevo de la lista de repuestos.

Que recibe: Rcbz -> Nodo repuesto cabeza,
            Rcl -> Nodo repuesto cola.

Que retorna: No retorna nada (void), deja la lista de repuestos cargada en memoria.
*/
void leer_arch_rep(Nrepuesto **Rcbz, Nrepuesto **Rcl)
{
    Repuesto r;

    FILE *Rach = fopen("repuestos.dat", "rb");

    if(Rach == NULL)
    {
        Rach = fopen("repuestos.dat", "ab");
        if(Rach == NULL)
        {
            puts("no se pudo crear el archivo de repuestos :(");
            exit(1);
        }
    }
    else
        while(fread(&r, sizeof(Repuesto), 1, Rach))
            *Rcl = Insertar_Nodo_Rep(Rcbz, Rcl, r);

    fclose(Rach);
}

/*
Nombre: buscar_id_rep

Que hace: Recorre la lista de repuestos comparando el id de cada nodo con
          el id buscado.

Que recibe: Rcbz -> Nodo repuesto cabeza,
            referencia -> id que se busca.

Que retorna: La posicion (indice desde 0) del repuesto si lo encuentra,
             o -1 si ningun repuesto tiene ese id.
*/
int buscar_id_rep(Nrepuesto **Rcbz, int referencia)
{
    Nrepuesto *IND = *Rcbz;
    int cont = 0;
    while(IND)
    {
        if(IND->rep.idRepuesto == referencia)
            return cont;
        else
            cont++;

        IND = IND->prox;
    }

    return -1;
}

/*
Nombre: CRUD_rep

Que hace: Muestra el submenu de repuestos (crear, listar, modificar,
          borrar/desactivar) y llama a la funcion correspondiente segun
          la opcion elegida.

Que recibe: Rcbz -> Nodo repuesto cabeza,
            Rcl -> Nodo repuesto cola,
            Ocbz -> Nodo orden cabeza (para saber si un repuesto tiene
            ordenes al editar/borrar).

Que retorna: No retorna nada (void); se mantiene en el submenu hasta que
             el usuario elige volver (0).
*/
void CRUD_rep(Nrepuesto **Rcbz, Nrepuesto **Rcl, Norden **Ocbz)
{
    int op;
    do
    {
        puts("+--------------------------------+");
        puts("|                                |");
        printf("|======= MEN%c DE REPUESTOS ======|\n", 233);
        puts("|                                |");
        puts("+--------------------------------+\n");
        puts("+--------------------------------+");
        puts("| 1. Crear repuesto              |");
        puts("| 2. Listar repuestos            |");
        puts("| 3. Modificar repuesto          |");
        puts("| 4. Borrar/Desactivar repuesto  |");
        puts("| 0. Volver                      |");
        puts("+--------------------------------+");
        printf("Seleccione una opci%cn: ", 162);

        leerint(&op);

        switch(op)
        {
        case 1:
            system("cls");
            CREATE_REPUESTO(Rcbz, Rcl);
            break;

        case 2:
            system("cls");
            READ_REPUESTO(Rcbz, Rcl);
            break;

        case 3:
            system("cls");
            UPDATE_REPUESTO(Rcbz, Rcl);
            break;

        case 4:
            system("cls");
            DISABLE_REPUESTO(Rcbz, Rcl, Ocbz);
            break;

        case 0:
            system("cls");
            break;

        default:
            mensaje("\nERROR: Tienes que ingresar un numero de las opciones que se muestran!");
            break;
        }
    }
    while(op != 0);
}

/*
Nombre: CREATE_REPUESTO

Que hace: Pide id, nombre, cantidad, precio y se calcula el subtotal final validando cada dato (id unico y
          en rango, cantidad no menor a 0, ect.), arma un
          repuesto activo, lo inserta en la lista y lo agrega al final de
          repuestos.dat.

Que recibe: Rcbz -> Nodo repuesto cabeza,
            Rcl -> Nodo repuesto cola.

Que retorna: No retorna nada (void); deja el nuevo repuesto creado en
             memoria.
*/
void CREATE_REPUESTO(Nrepuesto **Rcbz, Nrepuesto **Rcl)
{
    Repuesto r;

    do
    {
        puts("===================================");
        puts("||                               ||");
        puts("||===  Creador de Repuestos   ===||");
        puts("||                               ||");
        puts("===================================\n");
        printf("Ingrese id del repuesto (1-32767): ");
        leerint(&r.idRepuesto);

        if(r.idRepuesto < 1 || r.idRepuesto > 32767)
            mensaje("\nERROR: Ingrese un numero valido! (entre 0 y 32767)");
        else if(buscar_id_rep(Rcbz, r.idRepuesto) >= 0)
        {
            mensaje("\nERROR: Este id ya existe elija otro por favor!");
            r.idRepuesto = -1;
        }

    }
    while(r.idRepuesto < 1 || r.idRepuesto > 32767);
    system("cls");

    do
    {
        puts("===================================");
        puts("||                               ||");
        puts("||===  Creador de Repuestos   ===||");
        puts("||                               ||");
        puts("===================================\n");
        printf("Ingrese id del repuesto (1-32767): %d\n", r.idRepuesto);
        printf("Ingrese nombre del repuesto (solo letras, guion y espacio): ");
        fgets(r.nombre, 40, stdin);
        limpiar_salto(r.nombre);

        if(validar_nombre_rep(r.nombre))
            *(r.nombre) = '\n';
        else if(buscar_nombre_rep(Rcbz, r.nombre) >= 0)
        {
            mensaje("\nERROR: Este nombre ya existe elija otro!");
            *(r.nombre) = '\n';
        }
    }
    while(*(r.nombre) == '\n');
    system("cls");

    do
    {
        puts("===================================");
        puts("||                               ||");
        puts("||===  Creador de Repuestos   ===||");
        puts("||                               ||");
        puts("===================================\n");
        printf("Ingrese id del repuesto (1-32767): %d\n", r.idRepuesto);
        printf("Ingrese nombre del repuesto (solo letras, guion y espacio): %s\n", r.nombre);
        printf("Ingrese cantidad (1-100): ");
        leerint(&r.cantidad);

        if(r.cantidad < 1 || r.cantidad > 100)
            mensaje("\nERROR: La cantidad debe de ser minimo 1 y maximo 100!");

    }
    while(r.cantidad < 1 || r.cantidad > 100);
    system("cls");

    do
    {
        puts("===================================");
        puts("||                               ||");
        puts("||===  Creador de Repuestos   ===||");
        puts("||                               ||");
        puts("===================================\n");
        printf("Ingrese id del repuesto (1-32767): %d\n", r.idRepuesto);
        printf("Ingrese nombre del repuesto (solo letras, guion y espacio): %s\n", r.nombre);
        printf("Ingrese cantidad (1-100): %d\n", r.cantidad);
        printf("Ingrese precio unitario: ");
        leerfloat(&r.precioUnitario);

        if(r.precioUnitario < 49.99 || r.precioUnitario > 5000.00)
            mensaje("\nERROR: El precio debe de estar entre 49.99 y maximo 5000.00!");

    }
    while(r.precioUnitario < 49.99 || r.precioUnitario > 5000.00);
    system("cls");

    puts("===================================");
    puts("||                               ||");
    puts("||===  Creador de Repuestos   ===||");
    puts("||                               ||");
    puts("===================================\n");
    printf("Ingrese id del repuesto (1-32767): %d\n", r.idRepuesto);
    printf("Ingrese nombre del repuesto (solo letras, guion y espacio): %s\n", r.nombre);
    printf("Ingrese cantidad (1-100): %d\n", r.cantidad);
    printf("Ingrese precio unitario: %.2f\n", r.precioUnitario);
    r.subtotal = (r.precioUnitario * r.cantidad);
    printf("Subtotal: %.2f\n",r.subtotal);

    if((*Rcl = Insertar_Nodo_Rep(Rcbz, Rcl, r)) == NULL)
    {
        mensaje("\nERROR: No se pudo crear el repuesto!");
    }
    else
    {
        FILE *Rach = fopen("repuestos.dat", "ab");
        if(Rach == NULL)
        {
            mensaje("\nError: No se pudo abrir el archivo de repuestos!");
            return;
        }

        fwrite(&r, sizeof(Repuesto), 1, Rach);
        fclose(Rach);

        mensaje("\nSe creo el repuesto!");
    }

}

/*
Nombre: READ_REPUESTO

Que hace: Calcula el ancho de columna segun el dato mas largo de cada campo
          e imprime una tabla con todos los repuestos registrados y su estado.

Que recibe: Rcbz -> Nodo repuesto cabeza,
            Rcl -> Nodo repuesto cola (no se usa).

Que retorna: No retorna nada (void), solo imprime la lista en pantalla.
*/
void READ_REPUESTO(Nrepuesto **Rcbz, Nrepuesto **Rcl)
{
    if(*Rcbz == NULL)
    {
        mensaje("\nERROR: No hay repuestos aun, por favor cree alguno!");
        return;
    }

    int TamID = 2;
    int TamNOM = 6;
    int TamCANT = 8;
    int TamPRE = 12;
    int TamSUB = 8;
    impresion_rep(Rcbz, &TamID, &TamNOM, &TamSUB);

    Nrepuesto *IND = *Rcbz;
    puts("===================================");;
    puts("||                               ||");
    puts("||=====  Lista de Repuestos  ====||");
    puts("||                               ||");
    puts("===================================\n");
    printf("%-*s | %-*s | %-*s | %-*s | %-*s\n", TamID, "ID",
           TamNOM, "NOMBRE",
           TamCANT, "CANTIDAD",
           TamPRE, "PRECIO UNIT.",
           TamSUB, "SUBTOTAL");

    int i, j;
    for(i = 0, j = TamID + TamNOM + TamCANT + TamPRE + TamSUB; i < 1.5*j; i++)
        printf("=");
    printf("\n");

    while(IND)
    {
        printf("%-*d | %-*s | %-*d | %-*.2f | %-*.2f\n", TamID, IND->rep.idRepuesto,
               TamNOM, IND->rep.nombre,
               TamCANT, IND->rep.cantidad,
               TamPRE, IND->rep.precioUnitario,
               TamSUB, IND->rep.subtotal);

        IND = IND->prox;
    }

    printf("\n");
    system("pause");
    system("cls");
}

/*
Nombre: UPDATE_REPUESTO

Que hace: Busca el repuesto por id, muestra un submenu para elegir que
          campo modificar (repite hasta que el usuario presiona X), pide
          confirmacion y, si se confirma, actualiza el nodo en memoria y
          el registro en repuestos.dat. Si el id cambio, actualiza tambien
          las ordenes que lo referencian.

Que recibe: Rcbz -> Nodo repuesto cabeza,
            Rcl -> Nodo repuesto cola,
            Ocbz -> Nodo orden cabeza (para el cambio de id).

Que retorna: No retorna nada (void).
*/
void UPDATE_REPUESTO(Nrepuesto **Rcbz, Nrepuesto **Rcl)
{
    if(*Rcbz == NULL)
    {
        mensaje("\nERROR: No hay repuestos aun, por favor cree alguno!");
        return;
    }

    int buscar, pos;
    printf("Ingrese el id del Repuesto a buscar: ");
    leerint(&buscar);
    if((pos = buscar_id_rep(Rcbz, buscar)) < 0)
    {
        mensaje("El ID no existe y/o no es valido");
        return;
    }

    system("cls");

    Repuesto r;
    Nrepuesto *IND = *Rcbz;
    for(int i = 0; i < pos; i++)
        IND = IND->prox;

    r = IND->rep;

    char eleccion;

    do
    {
        puts("==================================");;
        puts("||                              ||");
        puts("||====  Modificar Repuesto  ====||");
        puts("||                              ||");
        puts("==================================");
        printf("1. ID: %d\n", r.idRepuesto);
        printf("2. Nombre: %s\n", r.nombre);
        printf("3. Cantidad: %d\n", r.cantidad);
        printf("4. Precio Unit.: %.2f\n", r.precioUnitario);
        printf("Subtotal: %.2f\n", r.subtotal);
        printf("X. Salir\n\n");
        printf("Seleccione una opcion: ");
        eleccion = getchar();
        if(eleccion != '\n')
            clean_teclado();

        switch(eleccion)
        {
        case '1':
            system("cls");
            do
            {
                printf("Ingrese el nuevo id del repuesto: ");
                leerint(&r.idRepuesto);

                if(r.idRepuesto < 1 || r.idRepuesto > 32767)
                {
                    mensaje("\nERROR: Ingrese un numero valido! (entre 1 y 32767)");
                    r.idRepuesto = -1;
                }
                else if(buscar_id_rep(Rcbz, r.idRepuesto) >= 0)
                {
                    mensaje("\nERROR: Este id ya existe elija otro por favor!");
                    r.idRepuesto = -1;
                }
            }
            while(r.idRepuesto < 1 || r.idRepuesto > 32767);
            system("cls");
            break;

        case '2':
            system("cls");
            do
            {
                printf("Ingrese el nuevo nombre: ");
                fgets(r.nombre, 40, stdin);
                limpiar_salto(r.nombre);
                if(*(r.nombre) != '\n')
                    if(validar_nombre_rep(r.nombre))
                        *(r.nombre) = '\n';
                    else if(buscar_nombre_rep(Rcbz, r.nombre) >= 0)
                    {
                        mensaje("\nERROR: Esta nombre ya existe elija otro!");
                        *(r.nombre) = '\n';
                    }
            }
            while(*(r.nombre) == '\n');
            system("cls");
            break;

        case '3':
            system("cls");
            do
            {
                printf("Ingrese la nueva cantidad: ");
                leerint(&r.cantidad);

                if(r.cantidad < 1 || r.cantidad > 100)
                    mensaje("\nERROR: La cantidad debe de ser minimo 1 y maximo 100!");
            }
            while(r.cantidad < 1 || r.cantidad > 100);
            r.subtotal = r.precioUnitario * r.cantidad;
            system("cls");
            break;

        case '4':
            system("cls");
            do
            {
                printf("Ingrese el nuevo precio: ");
                leerfloat(&r.precioUnitario);

                if(r.precioUnitario < 49.99 || r.precioUnitario > 5000.00)
                    mensaje("\nERROR: El precio debe de estar entre 49.99 y maximo 5000.00!");
            }
            while(r.precioUnitario < 49.99 || r.precioUnitario > 5000.00);
            r.subtotal = r.precioUnitario * r.cantidad;
            system("cls");
            break;

        case 'x':
        case 'X':
            system("cls");
            break;

        default:
            mensaje("\nERROR: Tienes que ingresar una de las opciones que se muestran!");
            break;
        }
    }
    while(eleccion != 'x' && eleccion != 'X');

    do
    {
        puts("==================================");;
        puts("||                              ||");
        puts("||====  Modificar Repuesto  ====||");
        puts("||                              ||");
        puts("==================================");
        printf("1. ID: %d\n", r.idRepuesto);
        printf("2. Nombre: %s\n", r.nombre);
        printf("3. Cantidad: %d\n", r.cantidad);
        printf("4. Precio Unit.: %.2f\n", r.precioUnitario);
        printf("Subtotal: %.2f\n", r.subtotal);
        printf("Quieres guardar los cambios? (S/N): ");
        elige(&eleccion);
        if(eleccion == 'N')
        {
            mensaje("\nNo se guardaron los cambios!");
            return;
        }

    }
    while(eleccion != 'S' && eleccion != 'N');

    FILE *Rach = fopen("repuestos.dat", "r+b");
    if(Rach == NULL)
    {
        mensaje("\nError: Para abrir el archivo de repuestos!");
        return;
    }

    IND->rep = r;
    fseek(Rach, pos * sizeof(Repuesto), SEEK_SET);
    fwrite(&r, sizeof(Repuesto), 1, Rach);
    fclose(Rach);
    mensaje("\nSe guardaron los cambios correctamente!");
}

/*
Nombre: DISABLE_REPUESTO

Que hace: Busca el repuesto por id y, tras confirmar con el usuario, si el
          repuesto ya tiene alguna orden asignada solo lo marca como
          inactivo; si nunca tuvo ordenes lo elimina por completo de la
          lista y de repuestos.dat.

Que recibe: Rcbz -> Nodo repuesto cabeza,
            Rcl -> Nodo repuesto cola,
            Ocbz -> Nodo orden cabeza (para saber si el repuesto tiene ordenes).

Que retorna: No retorna nada (void).
*/
void DISABLE_REPUESTO(Nrepuesto **Rcbz, Nrepuesto **Rcl, Norden **Ocbz)
{
    if(*Rcbz == NULL)
    {
        mensaje("\nERROR: No hay repuestos aun, por favor cree alguno!");
        return;
    }

    int buscar, pos;
    printf("Ingrese el id del Repuesto a buscar: ");
    leerint(&buscar);
    if((pos = buscar_id_rep(Rcbz, buscar)) < 0)
    {
        mensaje("El ID no existe y/o no es valido");
        return;
    }
    system("cls");

    Nrepuesto *IND = *Rcbz;
    for(int i = 0; i < pos; i++)
        IND = IND->prox;

    char eleccion;

    do
    {
        puts("===========================================");;
        puts("||                                       ||");
        puts("||==========  Borrar Repuesto  ==========||");
        puts("||                                       ||");
        puts("===========================================");
        printf("ID: %d\n", IND->rep.idRepuesto);
        printf("Nombre: %s\n", IND->rep.nombre);
        printf("Cantidad: %d\n", IND->rep.cantidad);
        printf("Precio Unit.: %.2f\n", IND->rep.precioUnitario);
        printf("Subtotal: %.2f\n", IND->rep.subtotal);
        printf("Quieres borrar este repuesto? (S/N): ");
        elige(&eleccion);
        if(eleccion == 'N')
        {
            mensaje("\nEl repuesto no fue borrado!");
            return;
        }
    }
    while(eleccion != 'S' && eleccion != 'N');

    FILE *Rach = fopen("repuestos.dat", "r+b");
    if(Rach == NULL)
    {
        mensaje("\nError: No se pudo abrir el archivo de repuestos!");
        return;
    }
    //Borrarlo completamente
    FILE *temp = fopen("temp.dat", "wb");
    if(temp == NULL)
    {
        mensaje("\nError: no se pudo abrir el archivo temporal de repuestos!");
        return;
    }

    if(IND->ant)
        IND->ant->prox = IND->prox;
    else
        *Rcbz = IND->prox;

    if(IND->prox)
        IND->prox->ant = IND->ant;
    else
        *Rcl = IND->ant;

    free(IND);

    Repuesto r;
    while(fread(&r, sizeof(Repuesto), 1, Rach))
        if(r.idRepuesto != buscar)
            fwrite(&r, sizeof(Repuesto), 1, temp);

    fclose(Rach);
    fclose(temp);

    remove("repuestos.dat");
    rename("temp.dat", "repuestos.dat");
    mensaje("\nRepuesto borrado correctamente!");
}

/*
Nombre: Insertar_Nodo_Rep

Que hace: Reserva memoria para un nodo nuevo, copia el repuesto dentro y lo
          engancha al final de la lista doblemente enlazada (o como primer
          nodo si la lista estaba vacia).

Que recibe: Rcbz -> Nodo repuesto cabeza,
            Rcl -> Nodo repuesto cola,
            r -> struct repuesto ya validado que se quiere agregar.

Que retorna: Puntero al nodo nuevo (que pasa a ser la nueva cola), o NULL
             si no se pudo reservar memoria.
*/
Nrepuesto *Insertar_Nodo_Rep(Nrepuesto **Rcbz, Nrepuesto **Rcl, Repuesto r)
{
    Nrepuesto *nr = (Nrepuesto *) calloc(1, sizeof(Nrepuesto));

    if(nr == NULL)
    {
        printf("no se pudo asignar la memoria :(");
        return NULL;
    }

    nr->rep = r;
    nr->prox = NULL;
    nr->ant = *Rcl;

    if(*Rcbz == NULL)
        *Rcbz = nr;
    else if(*Rcl)
        (*Rcl)->prox = nr;

    return nr;
}

/*
Nombre: free_rep

Que hace: Recorre toda la lista de repuestos liberando cada nodo con free.

Que recibe: Rcbz -> Nodo repuesto cabeza (primer nodo de la lista).

Que retorna: No retorna nada (void).
*/
void free_rep(Nrepuesto *Rcbz)
{
    Nrepuesto *IND = Rcbz;
    while(Rcbz)
    {
        IND = Rcbz->prox;
        free(Rcbz);
        Rcbz = IND;
    }
}
