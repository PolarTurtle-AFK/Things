#include <stdio.h>
#include <stdlib.h>
#include "reporte.h"
#include "proyecto.h"

void REPORTES(Norden **Ocbz, Nvehiculo **Vcbz, Ncliente **Ccbz, Nmecanico **Mcbz, Nrepuesto **Rcbz)
{
    int op;
    do
    {
        puts("+-----------------------------------------+");
        puts("|                                         |");
        printf("|========= MEN%c DE REPORTES ========|\n", 233);
        puts("|                                         |");
        puts("+-----------------------------------------+\n");
        puts("+-----------------------------------------+");
        puts("| 1. Ingresos por Dia                     |");
        puts("| 2. Repuestos Mas Usados                 |");
        puts("| 3. Mec�nico con M�s �rdenes Completadas |");
        puts("| 4. Ordenes Pendientes por Vehiculo      |");
        puts("| 0. Volver                               |");
        puts("+-----------------------------------------+");
        printf("Seleccione una opci%cn: ", 162);

        leerint(&op);

        switch(op)
        {
        case 1:
            system("cls");

            break;

        case 2:
            system("cls");

            break;

        case 3:
            system("cls");

            break;

        case 4:
            system("cls");

            break;

        case 0:
            system("cls");
            break;

        default:
            mensaje("\nERROR: Tienes que ingresar un numero de las opciones que se muestran!");
            break;
        }
    }
    while(op != 0);
}

