#ifndef proyecto_H
#define proyecto_H
#include <string.h>
#include "structs.h"
#include "cliente.h"
#include "mecanico.h"
#include "OrdenTrabajo.h"
#include "vehiculo.h"
#include "repuesto.h"

void clean_teclado();

void leerint(int *c);

void limpiar_salto(char *s);

void mensaje(char *s);

int validar_fecha(int dia, int mes, int anio);

int num_dia(int mes, int anio);

int esBisiesto(int anio);

int validar_placa(char *s);

int contar_dig(int n);

void impresion_veh(Nvehiculo **Vcbz, int *TamID, int *TamMAR, int *TamMOD);

void elige(char *eleccion);

int validar_nombre(char *s);

int validar_telefono(char *s);

int buscar_nombre_cl(Ncliente **Ccbz, char *referencia);

int buscar_telefono_cl(Ncliente **Ccbz, char *referencia);

void impresion_cl(Ncliente **Ccbz, int *TamID, int *TamNOM);

int buscar_nombre_mec(Nmecanico **Mcbz, char *referencia);

void impresion_mec(Nmecanico **Mcbz, int *TamID, int *TamNOM, int *TamESP);

int validar_nombre_rep(char *s);

int buscar_nombre_rep(Nrepuesto **Rcbz, char *referencia);

void leerfloat(float *c);

void impresion_rep(Nrepuesto **Rcbz, int *TamID, int *TamNOM, int *TamSUB);

int verificar(Nvehiculo **Vcbz, Ncliente **Ccbz, Nmecanico **Mcbz, Nrepuesto **Rcbz);

int stock_repuestos(Nrepuesto **Rcbz);

int seguir_eligiendo(Nrepuesto **Rcbz, int *elegidos, int cant_elegidos);

void elegir_repuestos(OrdenTrabajo *OT, Nrepuesto **Rcbz, int n);

void impresion_ord(Norden **Ocbz, Ncliente **Ccbz, int *TamID, int *TamCL, int *TamEST, int *TamTOT);

char *estado(int n);

Nvehiculo *devolver_ind_veh(Nvehiculo **Vcbz, int referencia);

Ncliente *devolver_ind_cl(Ncliente **Ccbz, int referencia);

Nmecanico *devolver_ind_mec(Nmecanico **Mcbz, int referencia);

Nrepuesto *devolver_ind_rep(Nrepuesto **Rcbz, int referencia);

void actualizar_id_veh_en_ordenes(Norden **Ocbz, int id_viejo, int id_nuevo);

void actualizar_id_cl_en_ordenes(Norden **Ocbz, int id_viejo, int id_nuevo);

void actualizar_id_mec_en_ordenes(Norden **Ocbz, int id_viejo, int id_nuevo);

#endif
